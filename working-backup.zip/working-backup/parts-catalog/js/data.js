var abz = [
  { id: '0',
    name: '�������������������� ���������',
    description: '',
    images: [
      { imageURL: 'ka160.jpg',
        mapMarkers: [
          { top: '50.3',
            left: '6.2',
            width: '10.5',
            height: '9',
            href: '0,0'
          },
          { top: '28.7',
            left: '45.7',
            width: '17.8',
            height: '5',
            href: '0,1'
          },
          { top: '20.5',
            left: '3.7',
            width: '5.8',
            height: '5',
            href: '0,2'
          },
          { top: '10.4',
            left: '7.6',
            width: '13.6',
            height: '5',
            href: '0,3'
          },
          { top: '32.7',
            left: '89.45',
            width: '11.8',
            height: '5',
            href: '0,4'
          },
          { top: '26.3',
            left: '91',
            width: '15',
            height: '13.5',
            href: '0,5'
          },
          { top: '47.8',
            left: '91.2',
            width: '15.3',
            height: '5',
            href: '0,6'
          },
          { top: '42.4',
            left: '91.2',
            width: '15.3',
            height: '8',
            href: '41'
          },
          { top: '55.7',
            left: '46',
            width: '18.5',
            height: '5',
            href: '0,7'
          },
          { top: '73',
            left: '49.4',
            width: '14.5',
            height: '14',
            href: '0,8'
          },
          { top: '56.5',
            left: '6.2',
            width: '10.5',
            height: '5',
            href: '0,9'
          },
          { top: '21.9',
            left: '45.5',
            width: '17.4',
            height: '5',
            href: '11,7'
          },
          { top: '35.5',
            left: '44',
            width: '14.4',
            height: '5',
            href: '3'
          },
          { top: '42.1',
            left: '48',
            width: '22.4',
            height: '5',
            href: '2'
          },
          { top: '49',
            left: '46.3',
            width: '19.2',
            height: '5',
            href: '1'
          },
          { top: '98.8',
            left: '90.6',
            width: '14.3',
            height: '5',
            href: '25'
          }
        ]
      }
    ],
    children: [
      { id: 'id0000',
        name: '���������� ������������',
        catalogNumber: '',
        images: [
          { imageURL: '0.0.jpg',
            mapMarkers: [
              { top: '32.9',
                left: '87.4',
                width: '8',
                height: '5',
                href: '4'
              },
              { top: '82.1',
                left: '20',
                width: '10',
                height: '5',
                href: '5'
              }
            ]
          }
        ]
      },
      { id: 'id0001',
        name: '���������� �����������',
        catalogNumber: '8.4',
        images: [
          { imageURL: '8.4.jpg',
            mapMarkers: [
              { top: '29.3',
                left: '10',
                width: '9',
                height: '4',
                href: '11'
              },
              { top: '37',
                left: '9.6',
                width: '9',
                height: '4',
                href: '7'
              },
              { top: '46',
                left: '15.7',
                width: '9',
                height: '4',
                href: '11,5'
              },
              { top: '78',
                left: '61.7',
                width: '10',
                height: '4',
                href: '6'
              },
              { top: '72.5',
                left: '67',
                width: '10',
                height: '4',
                href: '11,6'
              },
              { top: '58',
                left: '92',
                width: '10',
                height: '4',
                href: '11,4'
              },
              { top: '69',
                left: '83.5',
                width: '10',
                height: '4',
                href: '11,3'
              },
              { top: '69',
                left: '71.8',
                width: '9',
                height: '4',
                href: '9'
              },
              { top: '64',
                left: '79.5',
                width: '9',
                height: '4',
                href: '8'
              },
              { top: '63.5',
                left: '90.5',
                width: '9',
                height: '4',
                href: '10'
              }
            ]
          }
        ]
      },
      { id: 'id0002',
        name: '������',
        catalogNumber: '1.7',
        images: [
          { imageURL: '1.7.jpg',
            mapMarkers: [
              { top: '7.5',
                left: '41.5',
                width: '13',
                height: '5',
                href: '13'
              },
              { top: '10.3',
                left: '96',
                width: '7',
                height: '5',
                href: '14'
              },
              { top: '96.7',
                left: '48.2',
                width: '12',
                height: '5',
                href: '12'
              },
              { top: '94.7',
                left: '76.8',
                width: '8',
                height: '5',
                href: '12,17'
              }
            ]
          }
        ]
      },
      { id: 'id0003',
        name: '�������� �������',
        catalogNumber: '6.80.01',
        images: [
          { imageURL: '6.80.01.jpg',
            mapMarkers: [
              { top: '47.2',
                left: '82.5',
                width: '32',
                height: '3',
                href: '15'
              },
              { top: '95',
                left: '73.5',
                width: '32',
                height: '3',
                href: '16'
              },
              { top: '27.2',
                left: '82.5',
                width: '32',
                height: '3',
                href: '17'
              },
              { top: '76.8',
                left: '83.5',
                width: '35',
                height: '3',
                href: '18'
              },
              { top: '31.5',
                left: '76.5',
                width: '39',
                height: '3',
                href: '19'
              },
              { top: '40.3',
                left: '81.8',
                width: '32',
                height: '3',
                href: '19,2'
              },
              { top: '42.8',
                left: '81.8',
                width: '32',
                height: '3',
                href: '19,3'
              },
              { top: '50.2',
                left: '82.8',
                width: '32',
                height: '3',
                href: '19,1'
              }
            ]
          }
        ]
      },
      { id: 'id0004',
        name: '�������� ����',
        catalogNumber: '6.9',
        images: [
          { imageURL: '6.9.jpg',
            mapMarkers: [
              { top: '48.2',
                left: '10.5',
                width: '20',
                height: '3.2',
                href: '20'
              },
              { top: '33.5',
                left: '10.5',
                width: '20',
                height: '3.2',
                href: '20,0'
              },
              { top: '36.5',
                left: '10.5',
                width: '20',
                height: '3.2',
                href: '20,1'
              },
              { top: '56',
                left: '10.5',
                width: '20',
                height: '3.2',
                href: '20,2'
              },
              { top: '40.4',
                left: '81',
                width: '20',
                height: '3.2',
                href: '22'
              },
              { top: '92.4',
                left: '88',
                width: '24',
                height: '3.2',
                href: '21'
              }
            ]
          }
        ]
      },
      { id: 'id0005',
        name: '����� ������������ � ���������� �����������',
        catalogNumber: '08.10.2001',
        images: [
          { imageURL: '08.10.2001.jpg',
            mapMarkers: [
              { top: '8.7',
                left: '40.5',
                width: '8',
                height: '2.2',
                href: '0,5,3'
              },
              { top: '10.8',
                left: '40.5',
                width: '8',
                height: '2.2',
                href: '0,5,4'
              },
              { top: '17.3',
                left: '43.5',
                width: '13',
                height: '2.2',
                href: '0,5,5'
              },
              { top: '28.8',
                left: '5.5',
                width: '13',
                height: '2.2',
                href: '0,5,6'
              },
              { top: '40.2',
                left: '40.5',
                width: '9',
                height: '2.2',
                href: '0,5,1'
              },
              { top: '43.3',
                left: '40.5',
                width: '9',
                height: '2.2',
                href: '0,5,2'
              },
              { top: '53.1',
                left: '41.4',
                width: '10',
                height: '2.2',
                href: '23,0'
              },
              { top: '59.6',
                left: '42',
                width: '13',
                height: '2.2',
                href: '0,5,5'
              },
              { top: '81.6',
                left: '40.8',
                width: '9',
                height: '2.2',
                href: '0,5,1'
              },
              { top: '84.6',
                left: '40.8',
                width: '9',
                height: '2.2',
                href: '0,5,0'
              },
              { top: '92.2',
                left: '60.3',
                width: '10',
                height: '2.2',
                href: '23,1'
              },
              { top: '73',
                left: '59.1',
                width: '8',
                height: '2.2',
                href: '23'
              },
              { top: '84.6',
                left: '94.3',
                width: '10',
                height: '2.2',
                href: '0,5,8'
              },
              { top: '82.4',
                left: '94.3',
                width: '10',
                height: '2.2',
                href: '0,5,7'
              },
              { top: '30.5',
                left: '58.1',
                width: '10',
                height: '2.2',
                href: '24'
              }
            ]
          }
        ],
        children: [
          { id: 'id000500',
            name: '��������',
            catalogNumber: '8.10.20',
            images: [
              { imageURL: '8.10.20.jpg' }
            ]
          },
          { id: 'id000501',
            name: '�������� (������) (2 ��.)',
            catalogNumber: '2.48.15',
            images: [
              { imageURL: '2.48.15.jpg' }
            ]
          },
          { id: 'id000502',
            name: '��������',
            catalogNumber: '8.10.17',
            images: [
              { imageURL: '8.10.17.jpg' }
            ]
          },
          { id: 'id000503',
            name: '����� (�����)',
            catalogNumber: '4.10.2',
            images: [
              { imageURL: '4.10.2.jpg' }
            ]
          },
          { id: 'id000504',
            name: '������',
            catalogNumber: '6.10.7'
          },
          { id: 'id000505',
            name: '����������� ������ ������ (2 ��.)',
            catalogNumber: '4.5.1.14.23',
            images: [
              { imageURL: '4.5.1.14.23.jpg' }
            ]
          },
          { id: 'id000506',
            name: '����������� ������ ������ (2 ��.)',
            catalogNumber: '4.5.1.13.24',
            images: [
              { imageURL: '4.5.1.13.24.jpg' }
            ]
          },
          { id: 'id000507',
            name: '��������',
            catalogNumber: '8.10.83',
            images: [
              { imageURL: '8.10.83.jpg' }
            ]
          },
          { id: 'id000508',
            name: '���������� ������',
            catalogNumber: '8.10.86',
            images: [
              { imageURL: '8.10.86.jpg' }
            ]
          }
        ]
      },
      { id: 'id0006',
        name: '������� ���������',
        catalogNumber: '4.14',
        images: [
          { imageURL: '4.14.jpg',
            mapMarkers: [
              { top: '42.6',
                left: '6.7',
                width: '6',
                height: '3',
                href: '33'
              },
              { top: '65.2',
                left: '14',
                width: '6',
                height: '3',
                href: '29'
              },
              { top: '69.4',
                left: '14.1',
                width: '6',
                height: '3',
                href: '30'
              },
              { top: '73.5',
                left: '14.2',
                width: '6',
                height: '3',
                href: '31'
              },
              { top: '90.1',
                left: '67.6',
                width: '6',
                height: '3',
                href: '32'
              },
              { top: '89.5',
                left: '92.8',
                width: '8',
                height: '3',
                href: '35'
              },
              { top: '86.7',
                left: '92.8',
                width: '8',
                height: '3',
                href: '34'
              },
              { top: '77',
                left: '92.8',
                width: '8',
                height: '3',
                href: '36'
              }
            ]
          }
        ]
      },
      { id: 'id0007',
        name: '���������� �����������',
        catalogNumber: '5.20',
        images: [
          { imageURL: '5.20.jpg',
            mapMarkers: [
              { top: '34.3',
                left: '8.5',
                width: '8',
                height: '4',
                href: '40'
              },
              { top: '86',
                left: '69.5',
                width: '8',
                height: '4',
                href: '38'
              },
              { top: '90.3',
                left: '69.5',
                width: '8',
                height: '4',
                href: '39'
              }
            ]
          }
        ]
      },
      { id: 'id0008',
        name: '���������� ���������������� �����������',
        catalogNumber: ''
      },
      { id: 'id0009',
        name: '����� ������',
        catalogNumber: '6.100.M'
      }
    ]
  },

  // 1.
  { id: '1',
    name: '������ �������� ��������',
    catalogNumber: '4.1',
    images: [
      { imageURL: '4.1.jpg',
        mapMarkers: [
          { left: '32.8',
            top: '88.5',
            width: '5.1',
            height: '4',
            href: '1,0'
          },
          { left: '48.8',
            top: '88.7',
            width: '5.1',
            height: '4',
            href: '1,1'
          },
          { left: '30.2',
            top: '43.3',
            width: '5.1',
            height: '4',
            href: '1,2'
          },
          { left: '64.5',
            top: '78.7',
            width: '5.6',
            height: '4',
            href: '1,4'
          },
          { left: '24.2',
            top: '86.9',
            width: '7.8',
            height: '4',
            href: '1,5'
          },
          { left: '41.5',
            top: '86.6',
            width: '7.8',
            height: '4',
            href: '1,6'
          }
        ]
      }
    ],
    children: [
      { id: 'id0101',
        name: '������',
        catalogNumber: '4.1.3',
        images: [
          { imageURL: '4.1.3.jpg' }
        ]
      },
      { id: 'id0102',
        name: '������',
        catalogNumber: '4.1.4',
        images: [
          { imageURL: '4.1.4.jpg' }
        ]
      },
      { id: 'id0103',
        name: '���������',
        catalogNumber: '4.1.6',
        images: [
          { imageURL: '4.1.6.jpg' }
        ]
      },
      { id: 'id0104',
        name: '���������',
        catalogNumber: '4.1.7',
        images: [
          { imageURL: '4.1.7.jpg' }
        ]
      },
      { id: 'id0105',
        name: '��������� (2 ��.)',
        catalogNumber: '4.1.49'
      },
      { id: 'id0106',
        name: '������������� (2 ��.)',
        catalogNumber: '6.90.1.51'
      },
      { id: 'id0107',
        name: '�������������',
        catalogNumber: '6.90.1.55'
      }
    ] // end Uzels array
  },

  // 2.
  { id: '2',
    name: '���������� ��������� ��������',
    catalogNumber: '8.2',
    images: [
      { imageURL: '8.2.jpg',
        mapMarkers: [
          { left: '52.5',
            top: '14',
            width: '11',
            height: '5',
            href: '2,0'
          },
          { left: '8',
            top: '64.5',
            width: '9.5',
            height: '4',
            href: '2,1'
          },
          { left: '10.5',
            top: '71.2',
            width: '15',
            height: '4',
            href: '2,2'
          }
        ]
      }
    ],
    children: [
      { id: 'id0201',
        name: '������',
        catalogNumber: '4.2.3',
        images: [
          { imageURL: '4.2.3.jpg' }
        ]
      },
      { id: 'id0202',
        name: '���������',
        catalogNumber: '4.2.11',
        images: [
          { imageURL: '4.2.11.jpg' }
        ]
      },
      { id: 'id0203',
        name: '������������� (2 ��.)',
        catalogNumber: '6.90.2.75'
      }
    ]
  },

  // 3.
  { id: '3',
    name: '������ ����������',
    catalogNumber: '4.23',
    images: [
      { imageURL: '4.23.jpg',
        mapMarkers: [
          { top: '23.5',
            left: '71',
            width: '20',
            height: '3',
            href: '3,1'
          },
          { top: '75.3',
            left: '75',
            width: '38',
            height: '3',
            href: '3,2'
          },
          { top: '89.5',
            left: '18',
            width: '24',
            height: '3',
            href: '3,0'
          }
        ]
      }
    ],
    children: [
      { id: 'id0300',
        name: '�����-������',
        catalogNumber: '5.23.4',
        images: [
          { imageURL: '5.23.4.jpg' }
        ]
      },
      { id: 'id0301',
        name: '������ ������',
        catalogNumber: '8.4.5',
        images: [
          { imageURL: '8.4.5.jpg' }
        ]
      },
      { id: 'id0302',
        name: '�������������',
        catalogNumber: '4.23.04.17',
        images: [
          { imageURL: '6.90.4.106.jpg' }
        ]
      }
    ]
  },

  // 4.
  { id: '4',
    name: '�������',
    catalogNumber: '4.3.1',
    images: [
      { imageURL: '4.3.1.jpg',
        mapMarkers: [
          { top: '57.8',
            left: '79.7',
            width: '6',
            height: '3',
            href: '4,0'
          },
          { top: '35.8',
            left: '40.8',
            width: '6',
            height: '3',
            href: '4,1'
          },
          { top: '47',
            left: '76.1',
            width: '5.7',
            height: '3',
            href: '4,2'
          },
          { top: '42.5',
            left: '81',
            width: '5.7',
            height: '3',
            href: '4,3'
          },
          { top: '74.4',
            left: '48.1',
            width: '5.7',
            height: '3',
            href: '4,4'
          },
          { top: '28.4',
            left: '71',
            width: '5.7',
            height: '3',
            href: '4,5'
          },
          { top: '79',
            left: '42.3',
            width: '5.7',
            height: '3',
            href: '4,6'
          },
          { top: '31.5',
            left: '92.3',
            width: '5.7',
            height: '3',
            href: '4,7'
          },
          { top: '37.8',
            left: '87',
            width: '5.7',
            height: '3',
            href: '4,8'
          },
          { top: '21.9',
            left: '77.4',
            width: '5.7',
            height: '3',
            href: '4,9'
          },
          { top: '19',
            left: '96.3',
            width: '5.7',
            height: '3',
            href: '4,10'
          },
          { top: '90.5',
            left: '36.3',
            width: '4.7',
            height: '3',
            href: '4,11'
          },
          { top: '97.6',
            left: '49.3',
            width: '5.7',
            height: '3',
            href: '4,12'
          },
          { top: '9.9',
            left: '55.4',
            width: '7',
            height: '3',
            href: '4,13'
          },
          { top: '60.4',
            left: '35.3',
            width: '5.7',
            height: '3',
            href: '4,14'
          },
          { top: '7.9',
            left: '36.1',
            width: '7',
            height: '3',
            href: '4,15'
          },
          { top: '18',
            left: '42.1',
            width: '7',
            height: '3',
            href: '4,16'
          },
          { top: '35',
            left: '62',
            width: '7',
            height: '3',
            href: '4,16'
          },
          { top: '12.6',
            left: '56',
            width: '7',
            height: '3',
            href: '4,17'
          },
          { top: '31.5',
            left: '47',
            width: '7',
            height: '3',
            href: '4,17'
          },
          { top: '18.8',
            left: '67.5',
            width: '7',
            height: '3',
            href: '4,18'
          },
          { top: '13.3',
            left: '40.1',
            width: '7',
            height: '2.5',
            href: '4,19'
          },
          { top: '21',
            left: '69.8',
            width: '7',
            height: '2.5',
            href: '4,20'
          },
          { top: '15.3',
            left: '40.1',
            width: '7',
            height: '2.5',
            href: '4,21'
          },
          { top: '23',
            left: '69.8',
            width: '7',
            height: '2.5',
            href: '4,22'
          },
          { top: '10.5',
            left: '40',
            width: '7',
            height: '2.5',
            href: '4,23'
          },
          { top: '25.1',
            left: '70',
            width: '7',
            height: '2.5',
            href: '4,24'
          },
          { top: '23.2',
            left: '6.8',
            width: '7.5',
            height: '2.5',
            href: '4,25'
          },
          { top: '87.5',
            left: '66.8',
            width: '7.5',
            height: '2.5',
            href: '4,26'
          },
          { top: '45.8',
            left: '4.5',
            width: '7.5',
            height: '2.5',
            href: '4,27'
          },
          { top: '25.7',
            left: '34',
            width: '7.5',
            height: '2.5',
            href: '4,27'
          },
          { top: '53.8',
            left: '6.9',
            width: '7.5',
            height: '2.5',
            href: '4,28'
          },
          { top: '17.8',
            left: '25.5',
            width: '7.5',
            height: '2.5',
            href: '4,28'
          },
          { top: '56.5',
            left: '13.4',
            width: '7.5',
            height: '2.5',
            href: '4,29'
          },
          { top: '20.9',
            left: '31',
            width: '7.5',
            height: '2.5',
            href: '4,29'
          },
          { top: '19.7',
            left: '10.3',
            width: '7.5',
            height: '2.5',
            href: '4,30'
          },
          { top: '50.3',
            left: '28.4',
            width: '7.5',
            height: '2.5',
            href: '4,31'
          },
          { top: '52.3',
            left: '28.4',
            width: '7.5',
            height: '2.5',
            href: '4,32'
          },
          { top: '3.7',
            left: '17',
            width: '7.5',
            height: '2.5',
            href: '4,33'
          },
          { top: '5.7',
            left: '17',
            width: '7.5',
            height: '2.5',
            href: '4,34'
          },
          { top: '7.7',
            left: '17',
            width: '7.5',
            height: '2.5',
            href: '4,35'
          },
          { top: '9.7',
            left: '17',
            width: '7.5',
            height: '2.5',
            href: '4,36'
          },
          { top: '35.6',
            left: '90',
            width: '5.7',
            height: '3',
            href: '4,37'
          },
          { top: '95',
            left: '54.8',
            width: '5.7',
            height: '3',
            href: '4,38'
          },
          { top: '32.5',
            left: '80.2',
            width: '6',
            height: '3',
            href: '4,39'
          },
          { top: '64',
            left: '11.6',
            width: '6.5',
            height: '3',
            href: '4,40'
          },
          { top: '78.2',
            left: '76.5',
            width: '6.5',
            height: '3',
            href: '4,41'
          },
          { top: '50.6',
            left: '83.2',
            width: '6.5',
            height: '3',
            href: '4,42'
          }
        ]
      }
    ],
    children: [
      { id: 'id0401',
        name: '���',
        catalogNumber: '4.3.1.19',
        images: [
          { imageURL: '4.3.1.19.jpg' }
        ]
      },
      { id: 'id0402',
        name: '���',
        catalogNumber: '4.3.1.20',
        images: [
          { imageURL: '4.3.1.20.jpg' }
        ]
      },
      { id: 'id0403',
        name: '������ (4 ��.)',
        catalogNumber: '4.3.1.21',
        images: [
          { imageURL: '4.3.1.21.jpg' }
        ]
      },
      { id: 'id0404',
        name: '������ (4 ��.)',
        catalogNumber: '4.3.1.22',
        images: [
          { imageURL: '4.3.1.22.jpg' }
        ]
      },
      { id: 'id0405',
        name: '������ (2 ��.)',
        catalogNumber: '3.3.1.23',
        images: [
          { imageURL: '3.3.1.23.jpg' }
        ]
      },
      { id: 'id0406',
        name: '������ (2 ��.)',
        catalogNumber: '4.3.1.24',
        images: [
          { imageURL: '4.3.1.24.jpg' }
        ]
      },
      { id: 'id0407',
        name: '���������� (2 ��.)',
        catalogNumber: '4.3.1.25',
        images: [
          { imageURL: '4.3.1.25.jpg' }
        ]
      },
      { id: 'id0408',
        name: '����� (2 ��.)',
        catalogNumber: '3.3.1.26',
        images: [
          { imageURL: '3.3.1.26.jpg' }
        ]
      },
      { id: 'id0409',
        name: '������ (2 ��.)',
        catalogNumber: '3.3.1.27',
        images: [
          { imageURL: '3.3.1.27.jpg' }
        ]
      },
      { id: 'id0410',
        name: '������ (2 ��.)',
        catalogNumber: '3.3.1.28',
        images: [
          { imageURL: '3.3.1.28.jpg' }
        ]
      },
      { id: 'id0411',
        name: '������ (2 ��.)',
        catalogNumber: '3.3.1.29',
        images: [
          { imageURL: '3.3.1.29.jpg' }
        ]
      },
      { id: 'id0412',
        name: '����',
        catalogNumber: '4.3.1.30',
        images: [
          { imageURL: '4.3.1.30.jpg' }
        ]
      },
      { id: 'id0413',
        name: '���������� (2 ��.)',
        catalogNumber: '4.3.1.32',
        images: [
          { imageURL: '4.3.1.32.jpg' }
        ]
      },
      { id: 'id0414',
        name: '��������� (12 ��.)',
        catalogNumber: '4.3.1.13.4',
        images: [
          { imageURL: '4.3.1.13.4.jpg' }
        ]
      },
      { id: 'id0415',
        name: '������ �������� (4 ��.)',
        catalogNumber: '4.3.1.58',
        images: [
          { imageURL: '4.3.1.58.jpg' }
        ]
      },
      { id: 'id0416',
        name: '������� (12 ��.)',
        catalogNumber: '4.3.1.13.3',
        images: [
          { imageURL: '4.3.1.13.3.jpg' }
        ]
      },
      { id: 'id0417',
        name: '������ ������ (8 ��.)',
        catalogNumber: '4.3.1.13.2',
        images: [
          { imageURL: '4.3.1.13.2.jpg' }
        ]
      },
      { id: 'id0418',
        name: '������ ����� (4 ��.)',
        catalogNumber: '4.3.1.13.1',
        images: [
          { imageURL: '4.3.1.13.1.jpg' }
        ]
      },
      { id: 'id0419',
        name: '������� (������) (8 ��.)',
        catalogNumber: '4.3.1.13.5',
        images: [
          { imageURL: '4.3.1.13.5.jpg' }
        ]
      },
      { id: 'id0420',
        name: '���� �20 (24 ��.)',
        catalogNumber: '4.3.1.13.7'
      },
      { id: 'id0421',
        name: '���� �30 (20 ��.)',
        catalogNumber: '4.3.1.13.8'
      },
      { id: 'id0422',
        name: '����� �20 (48 ��.)',
        catalogNumber: '4.3.1.13.9'
      },
      { id: 'id0423',
        name: '����� �30 (40 ��.)',
        catalogNumber: '4.3.1.13.10'
      },
      { id: 'id0424',
        name: '����� ����������� (24 ��.)',
        catalogNumber: '4.3.1.13.11'
      },
      { id: 'id0425',
        name: '����� 30 (20 ��.)',
        catalogNumber: '4.3.1.13.12'
      },
      { id: 'id0426',
        name: '���� �������������� (30 ��.)',
        catalogNumber: '4.3.1.15.35',
        images: [
          { imageURL: '4.3.1.15.35.jpg' }
        ]
      },
      { id: 'id0427',
        name: '���� �������������� (10 ��.)',
        catalogNumber: '4.3.1.15.36',
        images: [
          { imageURL: '4.3.1.15.36.jpg' }
        ]
      },
      { id: 'id0428',
        name: '���� �������������� (8 ��.)',
        catalogNumber: '4.3.1.15.37',
        images: [
          { imageURL: '4.3.1.15.37.jpg' }
        ]
      },
      { id: 'id0429',
        name: '���� �������������� (4 ��.)',
        catalogNumber: '4.3.1.15.38',
        images: [
          { imageURL: '4.3.1.15.38.jpg' }
        ]
      },
      { id: 'id0430',
        name: '���� �������������� (4 ��.)',
        catalogNumber: '4.3.1.15.39',
        images: [
          { imageURL: '4.3.1.15.39.jpg' }
        ]
      },
      { id: 'id0431',
        name: '���� �������������� (6 ��.)',
        catalogNumber: '4.3.1.15.40',
        images: [
          { imageURL: '4.3.1.15.40.jpg' }
        ]
      },
      { id: 'id0432',
        name: '�������',
        catalogNumber: '4.3.1.15.41',
        images: [
          { imageURL: '4.3.1.15.41.jpg' }
        ]
      },
      { id: 'id0433',
        name: '�������',
        catalogNumber: '4.3.1.15.42',
        images: [
          { imageURL: '4.3.1.15.42.jpg' }
        ]
      },
      { id: 'id0434',
        name: '���� �12 (156 ��.)',
        catalogNumber: '4.3.1.15.45'
      },
      { id: 'id0435',
        name: '����� 12.65� (156 ��.)',
        catalogNumber: '4.3.1.15.46'
      },
      { id: 'id0436',
        name: '����� �12 (156 ��.)',
        catalogNumber: '4.3.1.15.47'
      },
      { id: 'id0437',
        name: '����� 12 (156 ��.)',
        catalogNumber: '4.3.1.15.48'
      },
      { id: 'id0438',
        name: '��������� (2 ��.)',
        catalogNumber: '4.3.1.120'
      },
      { id: 'id0439',
        name: '��������� (2 ��.)',
        catalogNumber: '4.3.1.121'
      },
      { id: 'id0440',
        name: '������� (2 ��.)',
        catalogNumber: '4.3.1.126'
      },
      { id: 'id0441',
        name: '������ (12 ��.)',
        catalogNumber: '4.3.1.131'
      },
      { id: 'id0442',
        name: '���������������� (2 ��.)',
        catalogNumber: '4.3.1.130'
      },
      { id: 'id0443',
        name: '������������� (2 ��.)',
        catalogNumber: '6.90.3.132'
      }
    ]
  },

  // 5.
  { id: '5',
    name: '��������',
    catalogNumber: '3.3.1.2',
    images: [
      { imageURL: '3.3.1.2.jpg',
        mapMarkers: [
          { left: '7',
            top: '49.3',
            width: '9.8',
            height: '4',
            href: '5,0'
          },
          { left: '74',
            top: '62.8',
            width: '9.8',
            height: '4',
            href: '5,1'
          },
          { left: '37',
            top: '15',
            width: '9.8',
            height: '4',
            href: '5,2'
          },
          { left: '50.2',
            top: '92.7',
            width: '9.8',
            height: '4',
            href: '5,3'
          },
          { left: '72',
            top: '77',
            width: '9.8',
            height: '4',
            href: '5,4'
          },
          { left: '31.8',
            top: '90',
            width: '11',
            height: '4',
            href: '5,5'
          },
          { left: '9.6',
            top: '82',
            width: '11',
            height: '4',
            href: '5,6'
          },
          { left: '7.5',
            top: '44',
            width: '11',
            height: '4',
            href: '5,7'
          },
          { left: '40.5',
            top: '94.8',
            width: '11',
            height: '4',
            href: '5,8'
          },
          { left: '92.5',
            top: '31.5',
            width: '11',
            height: '4',
            href: '5,9'
          },
          { left: '25.8',
            top: '79.8',
            width: '11',
            height: '4',
            href: '5,10'
          },
          { left: '73.5',
            top: '33.6',
            width: '11',
            height: '4',
            href: '5,11'
          },
          { left: '57.5',
            top: '69.5',
            width: '11',
            height: '4',
            href: '5,12'
          },
          { left: '7.5',
            top: '54',
            width: '11',
            height: '4',
            href: '5,13'
          }
        ]
      }
    ],
    children: [
      { id: 'id0501',
        name: '���-�������� (��� ����) (2 ��.)',
        catalogNumber: '3.3.1.2.2',
        images: [
          { imageURL: '3.3.1.2.2.jpg' }
        ]
      },
      { id: 'id0502',
        name: '������� (��������� ����) (2 ��.)',
        catalogNumber: '3.3.1.2.3',
        images: [
          { imageURL: '3.3.1.2.3.jpg' }
        ]
      },
      { id: 'id0503',
        name: '�����',
        catalogNumber: '3.3.10.21',
        images: [
          { imageURL: '3.3.10.21.jpg' }
        ]
      },
      { id: 'id0504',
        name: '�������� ����� (4 ��.)',
        catalogNumber: '3.3.1.2.7',
        images: [
          { imageURL: '3.3.1.2.7.jpg' }
        ]
      },
      { id: 'id0505',
        name: '���-�������� (������������� �������) (2 ��.)',
        catalogNumber: '3.3.1.2.8',
        images: [
          { imageURL: '3.3.1.2.8.jpg' }
        ]
      },
      { id: 'id0506',
        name: '������� (�������������) (2 ��.)',
        catalogNumber: '3.3.1.2.15',
        images: [
          { imageURL: '3.3.1.2.15.jpg' }
        ]
      },
      { id: 'id0507',
        name: '���� (2 ��.)',
        catalogNumber: '4.3.1.2.16',
        images: [
          { imageURL: '4.3.1.2.16.jpg' }
        ]
      },
      { id: 'id0508',
        name: '��������� (2 ��.)',
        catalogNumber: '3.3.1.2.50'
      },
      { id: 'id0509',
        name: '��������� (8 ��.)',
        catalogNumber: '3.3.1.2.51'
      },
      { id: 'id0510',
        name: '��������� (2 ��.)',
        catalogNumber: '3.3.1.2.52'
      },
      { id: 'id0511',
        name: '������� (2 ��.)',
        catalogNumber: '3.3.1.2.55'
      },
      { id: 'id0512',
        name: '������� (2 ��.)',
        catalogNumber: '3.3.1.2.56'
      },
      { id: 'id0513',
        name: '������ (2 ��.)',
        catalogNumber: '3.3.1.2.58'
      },
      { id: 'id0514',
        name: '������ (2 ��.)',
        catalogNumber: '3.3.1.2.59'
      },
      { id: 'id0515',
        name: '������',
        catalogNumber: '4.3.1.3',
        images: [
          { imageURL: '4.3.1.3.jpg' }
        ]
      },
      { id: 'id0516',
        name: '�����',
        catalogNumber: '4.3.1.10',
        images: [
          { imageURL: '4.3.1.10.jpg' }
        ]
      },
      { id: 'id0517',
        name: '�����',
        catalogNumber: '4.3.1.11',
        images: [
          { imageURL: '4.3.1.11.jpg' }
        ]
      },
      { id: 'id0518',
        name: '����� � �����',
        catalogNumber: '4.3.2'
      }
    ]
  },

  // 6.
  { id: '6',
    name: '���� ��������',
    catalogNumber: '4.4.10',
    images: [
      { imageURL: '4.4.10.jpg',
        mapMarkers: [
          { left: '11',
            top: '63.5',
            width: '18',
            height: '4',
            href: '6,0'
          },
          { left: '11',
            top: '56.8',
            width: '18',
            height: '4',
            href: '6,1'
          },
          { left: '13',
            top: '87',
            width: '22',
            height: '4',
            href: '6,2'
          },
          { left: '9',
            top: '16',
            width: '15',
            height: '4',
            href: '6,3'
          },
          { left: '70',
            top: '87',
            width: '22',
            height: '4',
            href: '6,4'
          },
          { left: '78',
            top: '18.7',
            width: '17',
            height: '4',
            href: '6,5'
          }
        ]
      }
    ],
    children: [
      { id: 'id0601',
        name: '����������� (2 ��.)',
        catalogNumber: '4.4.10.93'
      },
      { id: 'id0602',
        name: '������������ (2 ��.)',
        catalogNumber: '4.4.10.95',
        images: [
          { imageURL: '4.4.10.95.jpg' }
        ]
      },
      { id: 'id0603',
        name: '����������� ���������',
        catalogNumber: '4.4.10.104',
        images: [
          { imageURL: '4.4.10.104.jpg' }
        ]
      },
      { id: 'id0604',
        name: '�������������',
        catalogNumber: '6.90.4.106',
        images: [
          { imageURL: '6.90.4.106.jpg' }
        ]
      },
      { id: 'id0605',
        name: '������������������',
        catalogNumber: '4.4.10.108',
        images: [
          { imageURL: '4.4.10.108.jpg' }
        ]
      },
      { id: 'id0606',
        name: '������ ���������',
        catalogNumber: '4.4.10.3',
        images: [
          { imageURL: '4.4.10.3.jpg' }
        ]
      }
    ]
  },

  // 7.
  { id: '7',
    name: '���� ����',
    catalogNumber: '2.4.2',
    images: [
      { imageURL: '2.4.2.jpg',
        mapMarkers: [
          { left: '78',
            top: '62.8',
            width: '26',
            height: '5',
            href: '7,0'
          },
          { left: '13',
            top: '21.5',
            width: '26',
            height: '5',
            href: '7,1'
          },
          { left: '76.1',
            top: '90.5',
            width: '26',
            height: '5',
            href: '7,2'
          }
        ]
      }
    ],
    children: [
      { id: 'id0701',
        name: '����������� (2 ��.)',
        catalogNumber: '2.4.2.93'
      },
      { id: 'id0702',
        name: '������������ (2 ��.)',
        catalogNumber: '2.4.2.95'
      },
      { id: 'id0703',
        name: '�������� ����������',
        catalogNumber: '2.4.2.97',
        images: [
          { imageURL: '2.4.2.97.jpg' }
        ]
      }
    ]
  },

  // 8.
  { id: '8',
    name: '���� ��������',
    catalogNumber: '4.4.3',
    images: [
      { imageURL: '4.4.3.jpg',
        mapMarkers: [
          { left: '10',
            top: '80.5',
            width: '17',
            height: '5',
            href: '8,1'
          },
          { left: '23.5',
            top: '94.8',
            width: '17',
            height: '5',
            href: '8,2'
          },
          { left: '82.2',
            top: '64.8',
            width: '17',
            height: '5',
            href: '8,3'
          }
        ]
      }
    ],
    children: [
      { id: 'id0801',
        name: '������',
        catalogNumber: '4.4.3.1.�',
        images: [
          { imageURL: '4.4.3.1.jpg' }
        ]
      },
      { id: 'id0802',
        name: '����������� (3 ��.)',
        catalogNumber: '4.4.3.100'
      },
      { id: 'id0803',
        name: '������������ (3 ��.)',
        catalogNumber: '4.4.3.103',
        images: [
          { imageURL: '4.4.4.103.jpg' }
        ]
      },
      { id: 'id0804',
        name: '�������������',
        catalogNumber: '6.90.4.75'
      }
    ]
  },

  // 9.
  { id: '9',
    name: '���� �������',
    catalogNumber: '8.4.6',
    images: [
      { imageURL: '8.4.6.jpg',
        mapMarkers: [
          { left: '13.3',
            top: '24.3',
            width: '18',
            height: '5',
            href: '9,0'
          },
          { left: '73.5',
            top: '95.8',
            width: '18',
            height: '5',
            href: '9,1'
          },
          { left: '17.5',
            top: '93.3',
            width: '18',
            height: '5',
            href: '9,2'
          }
        ]
      }
    ],
    children: [
      { id: 'id0901',
        name: '����������� (2 ��.)',
        catalogNumber: '8.4.6.67'
      },
      { id: 'id0902',
        name: '�������� ����������',
        catalogNumber: '8.4.6.72',
        images: [
          { imageURL: '8.4.6.72.jpg' }
        ]
      },
      { id: 'id0903',
        name: '������� (4 ��.)',
        catalogNumber: '2.4.6.23',
        images: [
          { imageURL: '2.4.6.23.jpg' }
        ]
      }
    ]
  },

  // 10.
  { id: '10',
    name: '������ ��������',
    catalogNumber: '4.5.2',
    children: [
      { id: 'id1001',
        name: '������ (5 ��.)',
        catalogNumber: '4.4.3.1.�'
      },
      { id: 'id1002',
        name: '������������� (5 ��.)',
        catalogNumber: '6.90.4.75'
      }
    ]
  },

  // 11.
  { id: '11',
    name: '������ ����',
    catalogNumber: '8.5.3',
    images: [
      { imageURL: '8.5.3.jpg',
        mapMarkers: [
          { left: '82.5',
            top: '89',
            width: '16',
            height: '6',
            href: '11,0'
          },
          { left: '84',
            top: '78.5',
            width: '19.5',
            height: '6',
            href: '11,1'
          },
          { left: '89',
            top: '31.5',
            width: '20',
            height: '6',
            href: '11,2'
          }
        ]
      }
    ],
    children: [
      { id: 'id1101',
        name: '�������� ����������',
        catalogNumber: '8.5.3.6',
        images: [
          { imageURL: '8.5.3.6.jpg' }
        ]
      },
      { id: 'id1102',
        name: '����',
        catalogNumber: '8.5.3.1.2',
        images: [
          { imageURL: '8.5.3.1.2.jpg' }
        ]
      },
      { id: 'id1103',
        name: '�����-��������',
        catalogNumber: '8.5.3.1.56',
        images: [
          { imageURL: '8.5.3.1.56.jpg' }
        ]
      },
      { id: 'id1104',
        name: '����� ��������������',
        catalogNumber: '4.4.18'
      },
      { id: 'id1105',
        name: '����� ��������������',
        catalogNumber: '4.4.19'
      },
      { id: 'id1106',
        name: '����� ��������������',
        catalogNumber: '4.4.20'
      },
      { id: 'id1107',
        name: '����� ��������������',
        catalogNumber: '4.4.21'
      },
      { id: 'id1108',
        name: '������������� ������',
        catalogNumber: '4.5',
        images: [
          { imageURL: '4.5.jpg',
            mapMarkers: [
              { top: '70.5',
                left: '20.8',
                width: '8.7',
                height: '4',
                href: '11,7,0'
              },
              { top: '71.3',
                left: '63',
                width: '8.7',
                height: '4',
                href: '11,7,1'
              },
              { top: '84.8',
                left: '47',
                width: '8.7',
                height: '4',
                href: '11,7,2'
              },
              { top: '84.8',
                left: '7',
                width: '8.7',
                height: '4',
                href: '11,7,3'
              },
              { top: '75.3',
                left: '63.6',
                width: '10',
                height: '4',
                href: '11,7,4'
              },
              { top: '73',
                left: '92',
                width: '11',
                height: '4',
                href: '11,7,5'
              },
              { top: '96',
                left: '62.8',
                width: '10',
                height: '4',
                href: '11,7,6'
              },
              { top: '95.5',
                left: '75.8',
                width: '10',
                height: '4',
                href: '11,7,7'
              },
              { top: '92.3',
                left: '65.2',
                width: '8',
                height: '4',
                href: '11,7,9'
              },
              { top: '94.2',
                left: '92.2',
                width: '8',
                height: '4',
                href: '11,7,9'
              },
              { top: '98',
                left: '83.7',
                width: '8',
                height: '4',
                href: '11,7,10'
              },
              { top: '75.3',
                left: '52.5',
                width: '8',
                height: '4',
                href: '11,7,10'
              },
              { top: '91.4',
                left: '47.2',
                width: '8',
                height: '4',
                href: '11,7,11'
              },
              { top: '70.5',
                left: '52',
                width: '8',
                height: '4',
                href: '11,7,12'
              },
              { top: '80',
                left: '94.6',
                width: '8',
                height: '4',
                href: '11,7,12'
              }
            ]
          }
        ],
        children: [
        { id: 'id110700',
          name: '����������� ������ ������',
          catalogNumber: '4.5.1.13',
          images: [
            { imageURL: '4.5.1.13.jpg' }
          ]
        },
        { id: 'id110701',
          name: '����������� ������ ������ (5 ��.)',
          catalogNumber: '4.5.1.14',
          images: [
            { imageURL: '4.5.1.14.jpg' }
          ]
        },
        { id: 'id110702',
          name: '����������� ��������',
          catalogNumber: '4.5.2.�1',
          images: [
            { imageURL: '4.5.2.m1.jpg' }
          ]
        },
        { id: 'id110703',
          name: '�����-��������',
          catalogNumber: '4.5.2.56',
          images: [
            { imageURL: '4.5.2.56.jpg' }
          ]
        },
        { id: 'id110704',
          name: '����',
          catalogNumber: '4.5.2.2.�1',
          images: [
            { imageURL: '4.5.2.2.m1.jpg' }
          ]
        },
        { id: 'id110705',
          name: '�����',
          catalogNumber: '4.5.2.2.3.�1',
          images: [
            { imageURL: '4.5.2.2.3.m1.jpg' }
          ]
        },
        { id: 'id110706',
          name: '�����',
          catalogNumber: '4.11.1.7.2',
          images: [
            { imageURL: '4.11.1.7.2.jpg' }
          ]
        },
        { id: 'id110707',
          name: '������ (2 ��.)',
          catalogNumber: '4.11.1.7.5',
          images: [
            { imageURL: '4.11.1.7.5.jpg' }
          ]
        },
        { id: 'id110708',
          name: '���� �����',
          catalogNumber: '4.5.2.2.6�1',
          images: [
            { imageURL: '4.5.2.2.6�1.jpg' }
          ]
        },
        { id: 'id110709',
          name: '��������� (2 ��.)',
          catalogNumber: '4.5.2.45'
        },
        { id: 'id110710',
          name: '������� (3 ��.)',
          catalogNumber: '4.5.2.48'
        },
        { id: 'id110711',
          name: '������',
          catalogNumber: '4.5.2.47'
        },
        { id: 'id110712',
          name: '������� (2 ��.)',
          catalogNumber: '4.5.2.50'
        }
        ]
      },
    ]
  },

  // 12. ������
  { id: '12',
    name: '����� �������',
    catalogNumber: '1.7.2.�1',
    images: [
      { imageURL: '1.7.2.m1.jpg',
        mapMarkers: [
          { top: '74.8',
            left: '68.2',
            width: '11.5',
            height: '4',
            href: '12,0'
          },
          { top: '20',
            left: '88.2',
            width: '9',
            height: '4',
            href: '12,1'
          },
          { top: '59.8',
            left: '58.2',
            width: '9',
            height: '4',
            href: '12,2'
          },
          { top: '59.8',
            left: '69.2',
            width: '9',
            height: '4',
            href: '12,3'
          },
          { top: '59.8',
            left: '83',
            width: '12',
            height: '4',
            href: '12,4'
          },
          { top: '92.8',
            left: '66.3',
            width: '12',
            height: '4',
            href: '12,5'
          },
          { top: '60.2',
            left: '45.9',
            width: '9',
            height: '4',
            href: '12,6' // sito 9 (10-14)
          },
          { top: '64',
            left: '37',
            width: '10',
            height: '4',
            href: '12,7'
          },
          { top: '68',
            left: '26.5',
            width: '10',
            height: '4',
            href: '12,8'
          },
          { top: '71.8',
            left: '16.8',
            width: '10',
            height: '4',
            href: '12,9'
          },
          { top: '64.7',
            left: '65.8',
            width: '10',
            height: '4',
            href: '12,10'
          },
          { top: '66.1',
            left: '6',
            width: '10',
            height: '4',
            href: '12,11'
          },
          { top: '74.6',
            left: '54.7',
            width: '10',
            height: '4',
            href: '12,12'
          },
          { top: '9.4',
            left: '70',
            width: '14.4',
            height: '4',
            href: '12,13'
          },
          { top: '21.6',
            left: '9',
            width: '14.4',
            height: '4',
            href: '12,13'
          },
          { top: '5.2',
            left: '33.5',
            width: '10',
            height: '4',
            href: '12,14'
          },
          { top: '4.4',
            left: '47.7',
            width: '10',
            height: '4',
            href: '12,15'
          },
          { top: '93.3',
            left: '53.2',
            width: '10',
            height: '4',
            href: '12,15'
          }
        ]
      }
    ],
    children: [
      { id: 'id1201',
        name: '����� (54 ��.)',
        catalogNumber: '1.7.2.2.a',
        images: [
          { imageURL: '1.7.2.2.a.jpg' }
        ]
      },
      { id: 'id1202',
        name: '��������',
        catalogNumber: '1.7.2.3',
        images: [
          { imageURL: '1.7.2.3.jpg' }
        ]
      },
      { id: 'id1203',
        name: '����� ��������',
        catalogNumber: '1.7.2.4',
        images: [
          { imageURL: '1.7.2.4.jpg' }
        ]
      },
      { id: 'id1204',
        name: '����� ������� (25 ��.)',
        catalogNumber: '1.7.2.5',
        images: [
          { imageURL: '1.7.2.5.jpg' }
        ]
      },
      { id: 'id1205',
        name: '����� �������� (9 ��.)',
        catalogNumber: '1.7.2.7.�1',
        images: [
          { imageURL: '1.7.2.7.m1.jpg' }
        ]
      },
      { id: 'id1206',
        name: '���� (54 ��.)',
        catalogNumber: '1.7.2.15.8',
        images: [
          { imageURL: '1.7.2.15.8.jpg' }
        ]
      },
      { id: 'id1207',
        name: '����',
        catalogNumber: '1.7.2.9',
        images: [
          { imageURL: '1.7.2.9.jpg' },
          { imageURL: '1.7.2.9ref.jpg' }
        ]
      },
      { id: 'id1208',
        name: '����',
        catalogNumber: '1.7.2.10',
        images: [
          { imageURL: '1.7.2.9ref.jpg' }
        ]
      },
      { id: 'id1209',
        name: '����',
        catalogNumber: '1.7.2.11',
        images: [
          { imageURL: '1.7.2.9ref.jpg' }
        ]
      },
      { id: 'id1210',
        name: '����',
        catalogNumber: '1.7.2.12',
        images: [
          { imageURL: '1.7.2.9ref.jpg' }
        ]
      },
      { id: 'id1211',
        name: '����',
        catalogNumber: '1.7.2.13',
        images: [
          { imageURL: '1.7.2.9ref.jpg' }
        ]
      },
      { id: 'id1212',
        name: '����',
        catalogNumber: '1.7.2.14',
        images: [
          { imageURL: '1.7.2.9ref.jpg' }
        ]
      },
      { id: 'id1213',
        name: '������ (54 ��.)',
        catalogNumber: '1.7.2.24'
      },
      { id: 'id1214',
        name: '���� (2 ��.)',
        catalogNumber: '1.7.2.1.25.�',
        images: [
          { imageURL: '1.7.2.1.25.m.jpg' }
        ]
      },
      { id: 'id1215',
        name: '���������������� (2 ��.)',
        catalogNumber: '1.7.2.50'
      },
      { id: 'id1216',
        name: '������ (6 ��.)',
        catalogNumber: '1.7.2.52'
      },
      { id: 'id1217',
        name: '������� (54 ��.)',
        catalogNumber: '1.7.2.22',
        images: [
          { imageURL: '1.7.2.22.jpg' }
        ]
      },
      { id: 'id1218',
        name: '������� (8 ��.)',
        catalogNumber: '1.7.32',
        images: [
          { imageURL: '1.7.32.jpg' }
        ]
      }
    ]
  },

  // 13.
  { id: '13',
    name: '��������',
    catalogNumber: '1.7.2.1.�1',
    images: [
      { imageURL: '1.7.2.1.m1.jpg',
        mapMarkers: [
          { top: '70.7',
            left: '38.2',
            width: '11',
            height: '2.5',
            href: '13,1'
          },
          { top: '10.2',
            left: '43.5',
            width: '12',
            height: '2.5',
            href: '13,1'
          },
          { top: '10.8',
            left: '91.5',
            width: '12',
            height: '2.5',
            href: '13,2'
          },
          { top: '67.2',
            left: '83.1',
            width: '11',
            height: '2.5',
            href: '13,2'
          },
          { top: '69.6',
            left: '83.7',
            width: '11',
            height: '2.5',
            href: '13,3'
          },
          { top: '16.3',
            left: '92.8',
            width: '12',
            height: '2.5',
            href: '13,4'
          },
          { top: '72',
            left: '84.4',
            width: '12',
            height: '2.5',
            href: '13,5'
          },
          { top: '47.3',
            left: '61.1',
            width: '12',
            height: '2.5',
            href: '13,6'
          },
          { top: '29.3',
            left: '94',
            width: '12',
            height: '2.5',
            href: '13,7'
          },
          { top: '64.7',
            left: '82.2',
            width: '12',
            height: '2.5',
            href: '13,8'
          },
          { top: '34.1',
            left: '94.5',
            width: '12',
            height: '2.5',
            href: '13,9'
          },
          { top: '65.5',
            left: '60.8',
            width: '9',
            height: '2.5',
            href: '13,10'
          },
          { top: '67.8',
            left: '55.3',
            width: '9',
            height: '2.5',
            href: '13,11'
          },
          { top: '67.8',
            left: '9.3',
            width: '9',
            height: '2.5',
            href: '13,12'
          },
          { top: '21.2',
            left: '94.6',
            width: '9',
            height: '2.5',
            href: '13,13'
          },
          { top: '78.6',
            left: '83.8',
            width: '9',
            height: '2.5',
            href: '13,14'
          }
        ]
      }
    ],
    children: [
      { id: 'id1301',
        name: '��� (2 ��.)',
        catalogNumber: '1.7.2.1.12.�1',
        images: [
          { imageURL: '1.7.2.1.12.m1.jpg' }
        ]
      },
      { id: 'id1302',
        name: '������ (4 ��.)',
        catalogNumber: '1.7.2.1.5.�1',
        images: [
          { imageURL: '1.7.2.1.5.m1.jpg' }
        ]
      },
      { id: 'id1303',
        name: '������ (4 ��.)',
        catalogNumber: '1.7.2.1.6.�1',
        images: [
          { imageURL: '1.7.2.1.6.m1.jpg' }
        ]
      },
      { id: 'id1304',
        name: '������ (4 ��.)',
        catalogNumber: '1.7.2.1.8.�1',
        images: [
          { imageURL: '1.7.2.1.8.m1.jpg' }
        ]
      },
      { id: 'id1305',
        name: '���� (2 ��.)',
        catalogNumber: '1.7.2.1.9.�1',
        images: [
          { imageURL: '1.7.2.1.9.m1.jpg' }
        ]
      },
      { id: 'id1306',
        name: '������ (4 ��.)',
        catalogNumber: '1.7.2.1.13.�1',
        images: [
          { imageURL: '1.7.2.1.13.m1.jpg' }
        ]
      },
      { id: 'id1307',
        name: '���� (2 ��.)',
        catalogNumber: '1.7.2.1.15.�1',
        images: [
          { imageURL: '1.7.2.1.15.m1.jpg' }
        ]
      },
      { id: 'id1308',
        name: '���� (2 ��.)',
        catalogNumber: '1.7.2.1.16.�1',
        images: [
          { imageURL: '1.7.2.1.16.m1.jpg' }
        ]
      },
      { id: 'id1309',
        name: '������ (2 ��.)',
        catalogNumber: '1.7.2.1.17.�1',
        images: [
          { imageURL: '1.7.2.1.17.m1.jpg' }
        ]
      },
      { id: 'id1310',
        name: '����� (8 ��.)',
        catalogNumber: '1.7.2.1.18.�1',
        images: [
          { imageURL: '1.7.2.1.18.m1.jpg' }
        ]
      },
      { id: 'id1311',
        name: '��������� (4 ��.)',
        catalogNumber: '1.7.2.1.35'
      },
      { id: 'id1312',
        name: '������� (8 ��.)',
        catalogNumber: '1.7.2.1.37'
      },
      { id: 'id1313',
        name: '������ (4 ��.)',
        catalogNumber: '1.7.2.1.39'
      },
      { id: 'id1314',
        name: '������ (2 ��.)',
        catalogNumber: '1.7.2.1.41',
        images: [
          { imageURL: '1.7.2.1.41.jpg' }
        ]
      },
      { id: 'id1315',
        name: '������ (4 ��.)',
        catalogNumber: '1.7.2.1.42',
        images: [
          { imageURL: '1.7.2.1.42.jpg' }
        ]
      }
    ]
  },

  // 14.
  { id: '14',
    name: '���������� �����������������',
    catalogNumber: '1.7.3',
    images: [
      { imageURL: '1.7.3.jpg',
        mapMarkers: [
          { top: '14.2',
            left: '71.5',
            width: '11',
            height: '3.8',
            href: '14,0'
          },
          { top: '5.5',
            left: '64.8',
            width: '11',
            height: '3.8',
            href: '14,2'
          },
          { top: '66.4',
            left: '24.5',
            width: '11',
            height: '3.8',
            href: '14,1'
          },
          { top: '62.6',
            left: '92',
            width: '9',
            height: '3.8',
            href: '14,3'
          }
        ]
      }
    ],
    children: [
      { id: 'id1401',
        name: '�����',
        catalogNumber: '1.7.3.14',
        images: [
          { imageURL: '1.7.3.14.jpg' }
        ]
      },
      { id: 'id1402',
        name: '�������� (2 ��.)',
        catalogNumber: '1.7.3.47'
      },
      { id: 'id1403',
        name: '����� ��������������',
        catalogNumber: '1.7.3.15',
        images: [
          { imageURL: '1.7.3.15.jpg' }
        ]
      },
      { id: 'id1404',
        name: '�������������',
        catalogNumber: '6.90.7'
      }
    ]
  },

  // 15.
  { id: '15',
    name: '���� (113��.)',
    catalogNumber: '6.80.9',
    images: [
      { imageURL: '6.80.9.jpg' }
    ]
  },

  // 16.
  { id: '16',
    name: '��������� ���������',
    catalogNumber: '6.80.1',
    images: [
      { imageURL: '6.80.1.jpg',
        mapMarkers: [
          { top: '52.2',
            left: '6.5',
            width: '14',
            height: '3',
            href: '16,0'
          },
          { top: '60.4',
            left: '7.5',
            width: '16',
            height: '3',
            href: '16,0,0'
          },
          { top: '66.4',
            left: '7.5',
            width: '15',
            height: '3',
            href: '16,0,1'
          },
          { top: '45',
            left: '7',
            width: '15',
            height: '3',
            href: '16,0,2'
          },
          { top: '63.5',
            left: '7.5',
            width: '15',
            height: '3',
            href: '16,0,3'
          },
          { top: '48.7',
            left: '7',
            width: '15',
            height: '3',
            href: '16,0,4'
          },
          { top: '56.2',
            left: '7',
            width: '15',
            height: '3',
            href: '16,0,5'
          },
          { top: '77.5',
            left: '7.5',
            width: '15',
            height: '3',
            href: '16,1'
          },
          { top: '7.5',
            left: '67.4',
            width: '13',
            height: '3',
            href: '16,2'
          },
          { top: '33',
            left: '7',
            width: '13',
            height: '3',
            href: '16,2,0'
          },
          { top: '69.6',
            left: '7.5',
            width: '13',
            height: '3',
            href: '16,2,1'
          },
          { top: '72.6',
            left: '7.5',
            width: '13',
            height: '3',
            href: '16,2,2'
          },
          { top: '35.8',
            left: '92.8',
            width: '14',
            height: '3',
            href: '16,2,3'
          },
          { top: '39.8',
            left: '92.8',
            width: '14',
            height: '3',
            href: '16,2,4'
          },
          { top: '80.7',
            left: '7.7',
            width: '15',
            height: '3',
            href: '16,1,0'
          },
          { top: '83.7',
            left: '7.7',
            width: '15',
            height: '3',
            href: '16,1,1'
          },
          { top: '86.6',
            left: '7.7',
            width: '15',
            height: '3',
            href: '16,1,2'
          }
        ]
      }
    ],
    children: [
      { id: 'id1601',
        name: '����� (2 ��.)',
        catalogNumber: '6.80.1.3',
        images: [
          { imageURL: '6.80.1.3.jpg' }
        ],
        children: [
          { id: 'id160101',
            name: '����� (2 ��.)',
            catalogNumber: '6.80.1.3.1',
            images: [
              { imageURL: '6.80.1.3.1.jpg' }
            ]
          },
          { id: 'id160102',
            name: '����� (2 ��.)',
            catalogNumber: '1.80.14.2',
            images: [
              { imageURL: '1.80.14.2.jpg' }
            ]
          },
          { id: 'id160103',
            name: '������ (2 ��.)',
            catalogNumber: '��.5.1.3',
            images: [
              { imageURL: 'fn.5.1.3.jpg' }
            ]
          },
          { id: 'id160104',
            name: '������',
            catalogNumber: '1.80.14.4',
            images: [
              { imageURL: '1.80.14.4.jpg' }
            ]
          },
          { id: 'id160105',
            name: '������� (2 ��.)',
            catalogNumber: '4.80.1.3.10'
          },
          { id: 'id160106',
            name: '��������� (2 ��.)',
            catalogNumber: '4.80.1.3.11'
          }
        ]
      },
      { id: 'id1602',
        name: '���������',
        catalogNumber: '6.80.1.7.�',
        images: [
          { imageURL: '6.80.1.7.l.jpg' }
        ],
        children: [
          { id: 'id160201',
            name: '������ �������� (4 ��.)',
            catalogNumber: '6.80.1.7.5',
            images: [
              { imageURL: '6.80.1.7.5.jpg' }
            ]
          },
          { id: 'id160202',
            name: '���� (12 ��.)',
            catalogNumber: '6.80.1.7.7'
          },
          { id: 'id160203',
            name: '����� (24 ��.)',
            catalogNumber: '6.80.1.7.8'
          }
        ]
      },
      { id: 'id1603',
        name: '��������',
        catalogNumber: '6.80.1.8',
        images: [
          { imageURL: '6.80.1.8.jpg' }
        ],
        children: [
          { id: 'id160301',
            name: '������� (2 ��.)',
            catalogNumber: '6.80.1.57',
            images: [
              { imageURL: '6.80.1.57.jpg' }
            ]
          },
          { id: 'id160302',
            name: '������',
            catalogNumber: '6.80.1.63'
          },
          { id: 'id160303',
            name: '������',
            catalogNumber: '6.80.1.69'
          },
          { id: 'id160304',
            name: '��� ��������� �������',
            catalogNumber: '6.80.1.19',
            images: [
              { imageURL: '6.80.1.19.jpg' }
            ]
          },
          { id: 'id160305',
            name: '������',
            catalogNumber: '6.80.1.72'
          }
        ]
      }
    ]
  },

  // 17.
  { id: '17',
    name: '������',
    catalogNumber: '6.80.2',
    images: [
      { imageURL: '6.80.2.jpg',
        mapMarkers: [
          { top: '15.9',
            left: '29.5',
            width: '14',
            height: '3.5',
            href: '16,1,1'
          },
          { top: '19.3',
            left: '29.8',
            width: '14',
            height: '3.5',
            href: '16,1,2'
          },
          { top: '22.8',
            left: '29.8',
            width: '14',
            height: '3.5',
            href: '17,3'
          },
          { top: '46',
            left: '82.8',
            width: '14',
            height: '3.5',
            href: '17,4'
          },
          { top: '13.3',
            left: '86.4',
            width: '14',
            height: '3.5',
            href: '17,1,0'
          },
          { top: '17.8',
            left: '86.4',
            width: '14',
            height: '3.5',
            href: '17,1'
          },
          { top: '22',
            left: '85',
            width: '12',
            height: '3.5',
            href: '17,1'
          },
          { top: '25.8',
            left: '86.4',
            width: '14',
            height: '3.5',
            href: '17,0,1'
          },
          { top: '42.8',
            left: '83.8',
            width: '14',
            height: '3.5',
            href: '17,0,0'
          },
          { top: '28.8',
            left: '10',
            width: '14',
            height: '3.5',
            href: '17,6'
          },
          { top: '45.5',
            left: '39.5',
            width: '14',
            height: '3.5',
            href: '17,5'
          },
          { top: '55.8',
            left: '83',
            width: '14',
            height: '3.5',
            href: '17,2'
          },
          { top: '77.6',
            left: '77.4',
            width: '14',
            height: '3.5',
            href: '17,0,7'
          },
          { top: '80.8',
            left: '78',
            width: '15',
            height: '3.5',
            href: '17,0,8'
          },
          { top: '78.6',
            left: '57.4',
            width: '13',
            height: '3.5',
            href: '17,0,3'
          },
          { top: '83.6',
            left: '60.2',
            width: '14',
            height: '3.5',
            href: '17,0,9'
          },
          { top: '87.3',
            left: '59.7',
            width: '14',
            height: '3.5',
            href: '17,0,5'
          },
          { top: '91.8',
            left: '59.2',
            width: '13',
            height: '3.5',
            href: '17,0,4'
          },
          { top: '96.2',
            left: '58.7',
            width: '13',
            height: '3.5',
            href: '17,0,2'
          },
          { top: '96.2',
            left: '8.7',
            width: '13',
            height: '3.5',
            href: '17,0,6'
          }
        ]
      }
    ],
    children: [
      { id: 'id1701',
        name: '��� ��������� �������� ���������',
        catalogNumber: '6.80.2.4',
        images: [
          { imageURL: '6.80.2.4.jpg' }
        ],
        children: [
          { id: 'id170101',
            name: '����� (2 ��.)',
            catalogNumber: '6.80.1.3.1�'
          },
          { id: 'id170102',
            name: '���',
            catalogNumber: '6.80.2.4.1',
            images: [
              { imageURL: '6.80.2.4.1.jpg' }
            ]
          },
          { id: 'id170103',
            name: '����� (2 ��.)',
            catalogNumber: '1.80.14.2',
            images: [
              { imageURL: '1.80.14.2.jpg' }
            ]
          },
          { id: 'id170104',
            name: '������',
            catalogNumber: '1.80.14.3',
            images: [
              { imageURL: '1.80.14.3.jpg' }
            ]
          },
          { id: 'id170105',
            name: '������ (2 ��.) ',
            catalogNumber: '��.5.1.4'
          },
          { id: 'id170106',
            name: '������',
            catalogNumber: '1.80.14.5',
            images: [
              { imageURL: '1.80.14.5.jpg' }
            ]
          },
          { id: 'id170107',
            name: '��������� (2 ��.)',
            catalogNumber: '1.80.14.6',
            images: [
              { imageURL: '1.80.14.6.jpg' }
            ]
          },
          { id: 'id170108',
            name: '�������',
            catalogNumber: '6.80.2.4.9'
          },
          { id: 'id170109',
            name: '������� (2 ��.)',
            catalogNumber: '6.80.2.4.10'
          },
          { id: 'id170110',
            name: '��������� (2 ��.)',
            catalogNumber: '6.80.2.4.11'
          }
        ]
      },
      { id: 'id1702',
        name: '���������',
        catalogNumber: '6.80.1.7.�',
        images: [
          { imageURL: '6.80.1.7.l.jpg' }
        ],
        children: [
          { id: 'id170200',
            name: '������ ��������� (2 ��.)',
            catalogNumber: '6.80.2.6.5',
            images: [
              { imageURL: '6.80.2.6.5.jpg' }
            ]
          },
          { id: 'id170201',
            name: '���� (12 ��.)',
            catalogNumber: '6.80.2.6.7'
          },
          { id: 'id170202',
            name: '����� (24 ��.)',
            catalogNumber: '6.80.2.6.8'
          }
        ]
      },
      { id: 'id1703',
        name: '���� �������������� ',
        catalogNumber: '6.80.2.14',
        images: [
          { imageURL: '6.80.2.14.jpg' }
        ]
      },
      { id: 'id1704',
        name: '������ ',
        catalogNumber: '6.80.2.82'
      },
      { id: 'id1705',
        name: '������',
        catalogNumber: '6.80.2.83'
      },
      { id: 'id1706',
        name: '������',
        catalogNumber: '6.80.2.85'
      },
      { id: 'id1707',
        name: '�����-��������',
        catalogNumber: '6.80.2.93'
      }
    ]
  },

  // 18.
  { id: '18',
    name: '���� � �����',
    catalogNumber: '7.80.6.�',
    images: [
      { imageURL: '7.80.6.l.jpg',
        mapMarkers: [
          { top: '17',
            left: '46.8',
            width: '11',
            height: '4',
            href: '18,0,5'
          },
          { top: '57.7',
            left: '37.3',
            width: '11',
            height: '4',
            href: '18,0,5'
          },
          { top: '52.1',
            left: '37.3',
            width: '11',
            height: '4',
            href: '18,0,6'
          },
          { top: '57.7',
            left: '50.3',
            width: '12',
            height: '4',
            href: '18,0,1'
          },
          { top: '52',
            left: '50.3',
            width: '12',
            height: '4',
            href: '18,0,0'
          },
          { top: '24.5',
            left: '46',
            width: '11',
            height: '4',
            href: '18,0,4'
          },
          { top: '31.9',
            left: '47',
            width: '13',
            height: '4',
            href: '18,0,3'
          },
          { top: '37.4',
            left: '46.2',
            width: '11',
            height: '4',
            href: '18,0,7'
          },
          { top: '45',
            left: '45.6',
            width: '12',
            height: '4',
            href: '18,0,2'
          },
          { top: '42.2',
            left: '7.5',
            width: '10',
            height: '4',
            href: '18,0,8'
          },
          { top: '77.9',
            left: '38.1',
            width: '11',
            height: '4',
            href: '18,1,0'
          },
          { top: '25',
            left: '85',
            width: '11',
            height: '4',
            href: '18,0'
          },
          { top: '78.8',
            left: '70.7',
            width: '11',
            height: '4',
            href: '18,1'
          }
        ]
      }
    ],
    children: [
      { id: 'id1800',
        name: '����',
        catalogNumber: '7.80.6.2.�',
        images: [
          { imageURL: '7.80.6.2.l.jpg' }
        ],
        children: [
          { id: 'id180000',
            name: '������ �������',
            catalogNumber: '7.80.6.2.7.�',
            images: [
              { imageURL: '7.80.6.2.7.l.jpg' }
            ]
          },
          { id: 'id180001',
            name: '������ ������',
            catalogNumber: '7.80.6.2.8.�',
            images: [
              { imageURL: '7.80.6.2.8.l.jpg' }
            ]
          },
          { id: 'id180002',
            name: '������ �������',
            catalogNumber: '7.80.6.2.9.�',
            images: [
              { imageURL: '7.80.6.2.9.l.jpg' }
            ]
          },
          { id: 'id180003',
            name: '��������',
            catalogNumber: '7.80.6.2.10.�',
            images: [
              { imageURL: '7.80.6.2.10.jpg' }
            ]
          },
          { id: 'id180004',
            name: '���� ��������������',
            catalogNumber: '7.80.6.2.35',
            images: [
              { imageURL: '7.80.6.2.35.jpg' }
            ]
          },
          { id: 'id180005',
            name: '���� �������������� (9 ��.)',
            catalogNumber: '7.80.6.2.37',
            images: [
              { imageURL: '7.80.6.2.37.jpg' }
            ]
          },
          { id: 'id180006',
            name: '���� ��������������',
            catalogNumber: '7.80.6.2.38',
            images: [
              { imageURL: '7.80.6.2.38.jpg' }
            ]
          },
          { id: 'id180007',
            name: '���� ��������������',
            catalogNumber: '7.80.6.2.39',
            images: [
              { imageURL: '7.80.6.2.39.jpg' }
            ]
          },
          { id: 'id180008',
            name: '��������������������',
            catalogNumber: '7.80.6.15',
            images: [
              { imageURL: '7.80.6.15.jpg' }
            ]
          }
        ]
      },
      { id: 'id1801',
        name: '����� ��������',
        catalogNumber: '7.80.6.1.�',
        images: [
          { imageURL: '7.80.6.1.l.jpg' }
        ],
        children: [
          { id: 'id180100',
            name: '���� �������������� (2 ��.)',
            catalogNumber: '7.80.6.1.14'
          }
        ]
      }
    ]
  },

  // 19.
  { id: '19',
    name: '������',
    catalogNumber: '7.80.7.�',
    images: [
      { imageURL: '7.80.7.l.jpg',
        mapMarkers: [
          { top: '13.8',
            left: '45',
            width: '14',
            height: '6',
            href: '19,0,3'
          },
          { top: '21.5',
            left: '45',
            width: '14',
            height: '6',
            href: '19,0,4'
          },
          { top: '29.3',
            left: '45',
            width: '14',
            height: '6',
            href: '19,0,5'
          },
          { top: '37.3',
            left: '49',
            width: '14',
            height: '6',
            href: '19,0,0'
          },
          { top: '65.2',
            left: '49',
            width: '14',
            height: '6',
            href: '19,0,1'
          },
          { top: '93',
            left: '45',
            width: '14',
            height: '6',
            href: '19,0'
          },
          { top: '74.6',
            left: '73.5',
            width: '14',
            height: '6',
            href: '19,0,2'
          }
        ]
      }
    ],
    children: [
      { id: 'id1900',
        name: '������',
        catalogNumber: '6.80.7.1.�',
        children: [
          { id: 'id190000',
            name: '���� �������������� (2 ��.)',
            catalogNumber: '6.80.7.1.21',
            images: [
              { imageURL: '6.80.7.1.21.jpg' }
            ]
          },
          { id: 'id190001',
            name: '���� �������������� (14 ��.)',
            catalogNumber: '6.80.7.1.22',
            images: [
              { imageURL: '6.80.7.1.22.jpg' }
            ]
          },
          { id: 'id190002',
            name: '����������',
            catalogNumber: '6.80.7.1.19'
          },
          { id: 'id190003',
            name: '���� (32��.)',
            catalogNumber: '6.80.7.1.11'
          },
          { id: 'id190004',
            name: '����� (32��.)',
            catalogNumber: '6.80.7.1.15'
          },
          { id: 'id190005',
            name: '����� (32��.)',
            catalogNumber: '6.80.7.1.17'
          }
        ]
      },
      { id: 'id1902',
        name: '����',
        catalogNumber: '6.80.35'
      },
      { id: 'id1903',
        name: '���� (580 ��.)',
        catalogNumber: '6.80.20'
      },
      { id: 'id1904',
        name: '����� (580 ��.)',
        catalogNumber: '6.80.24'
      }
    ]
  },

  // 20
  { id: '20',
    name: '���� (124 ��.)',
    catalogNumber: '6.9.19',
    children: [
      { id: 'id2000',
        name: '����� (248 ��.)',
        catalogNumber: '6.9.31'
      },
      { id: 'id2001',
        name: '������ (2��.)',
        catalogNumber: '6.9.32'
      },
      { id: 'id2002',
        name: '����� ��������������',
        catalogNumber: '6.9.33'
      }
    ]
  },

  // 21
  { id: '21',
    name: '��������� ���������',
    catalogNumber: '6.9.11A',
    images: [
      { imageURL: '6.9.11a.jpg',
        mapMarkers: [
          { top: '12.9',
            left: '11',
            width: '19',
            height: '3.5',
            href: '21,10'
          },
          { top: '18.5',
            left: '11',
            width: '19',
            height: '3.5',
            href: '21,9'
          },
          { top: '25.6',
            left: '87.6',
            width: '19',
            height: '3.5',
            href: '21,2'
          },
          { top: '30.1',
            left: '87.6',
            width: '19',
            height: '3.5',
            href: '21,1'
          },
          { top: '34',
            left: '87.6',
            width: '19',
            height: '3.5',
            href: '21,0'
          },
          { top: '41.1',
            left: '87.6',
            width: '19',
            height: '3.5',
            href: '21,3'
          },
          { top: '81.7',
            left: '61.6',
            width: '18',
            height: '3',
            href: '21,3'
          },
          { top: '84.4',
            left: '63.9',
            width: '18',
            height: '3',
            href: '21,7'
          },
          { top: '87.3',
            left: '63.9',
            width: '18',
            height: '3',
            href: '21,6'
          },
          { top: '90',
            left: '63.9',
            width: '18',
            height: '3',
            href: '21,5'
          },
          { top: '92.8',
            left: '63.9',
            width: '18',
            height: '3',
            href: '21,4'
          },
          { top: '86.6',
            left: '12.7',
            width: '18',
            height: '3',
            href: '21,8'
          }
        ]
      }
    ],
    children: [
      { id: 'id2100',
      name: '���',
      catalogNumber: '6.9.11.26',
      images: [
        { imageURL: '6.9.11.26.jpg'}
      ]
      },
      { id: 'id2101',
      name: '�������',
      catalogNumber: '6.9.11.2',
      images: [
        { imageURL: '6.9.11.2.jpg'}
      ]
      },
      { id: 'id2102',
      name: '����',
      catalogNumber: '2.9.11.17',
      images: [
        { imageURL: '2.9.11.17.jpg'}
      ]
      },
      { id: 'id2103',
      name: '����� (2 ��.)',
      catalogNumber: '6.9.11.7',
      images: [
        { imageURL: '6.9.11.7.jpg'}
      ]
      },
      { id: 'id2104',
      name: '������ (4 ��.)',
      catalogNumber: '2.9.11.8',
      images: [
        { imageURL: '2.9.11.8.jpg'}
      ]
      },
      { id: 'id2105',
      name: '������ (2 ��.)',
      catalogNumber: '2.9.11.9',
      images: [
        { imageURL: '2.9.11.9.jpg'}
      ]
      },
      { id: 'id2106',
      name: '������ (2 ��.)',
      catalogNumber: '2.9.11.10',
      images: [
        { imageURL: '2.9.11.10.jpg'}
      ]
      },
      { id: 'id2107',
      name: '��������� (2 ��.)',
      catalogNumber: '6.9.11.59'
      },
      { id: 'id2108',
      name: '������� (2 ��.)',
      catalogNumber: '6.9.11.61'
      },
      { id: 'id2109',
      name: '������',
      catalogNumber: '6.9.11.65'
      },
      { id: 'id2110',
      name: '������ (2 ��.)',
      catalogNumber: '6.9.11.58'
      }
    ]
  },

  // 22
  { id: '22',
    name: '������',
    catalogNumber: '6.9.12',
    images: [
      { imageURL: '6.9.12.jpg',
        mapMarkers: [
          { top: '12.9',
            left: '18',
            width: '18',
            height: '3.5',
            href: '22,9'
          },
          { top: '24.2',
            left: '17.6',
            width: '18',
            height: '3.5',
            href: '22,11'
          },
          { top: '28.1',
            left: '17.2',
            width: '18',
            height: '3.5',
            href: '22,6'
          },
          { top: '31.7',
            left: '17.2',
            width: '18',
            height: '3.5',
            href: '22,7'
          },
          { top: '35.8',
            left: '17',
            width: '18',
            height: '3.5',
            href: '22,12'
          },
          { top: '72.6',
            left: '26',
            width: '18',
            height: '3.5',
            href: '22,14'
          },
          { top: '76.6',
            left: '25.8',
            width: '18',
            height: '3.5',
            href: '22,7'
          },
          { top: '80.8',
            left: '25.9',
            width: '18',
            height: '3.5',
            href: '22,0'
          },
          { top: '85.2',
            left: '25.9',
            width: '18',
            height: '3.5',
            href: '22,10'
          },
          { top: '6.6',
            left: '78.5',
            width: '18',
            height: '3.5',
            href: '22,1'
          },
          { top: '10.8',
            left: '78.5',
            width: '18',
            height: '3.5',
            href: '22,2'
          },
          { top: '27.2',
            left: '88.2',
            width: '18',
            height: '3.5',
            href: '22,8'
          },
          { top: '31.2',
            left: '88.2',
            width: '18',
            height: '3.5',
            href: '22,15'
          },
          { top: '35.7',
            left: '88.2',
            width: '18',
            height: '3.5',
            href: '22,16'
          },
          { top: '43.9',
            left: '84.8',
            width: '16',
            height: '3.5',
            href: '22,3'
          },
          { top: '72.4',
            left: '79.8',
            width: '18',
            height: '3.5',
            href: '22,5'
          },
          { top: '76.2',
            left: '79.8',
            width: '18',
            height: '3.5',
            href: '22,6'
          },
          { top: '80',
            left: '79.8',
            width: '18',
            height: '3.5',
            href: '22,11'
          },
          { top: '84',
            left: '80.2',
            width: '18',
            height: '3.5',
            href: '22,13'
          },
          { top: '88.5',
            left: '74.5',
            width: '18',
            height: '3.5',
            href: '22,4'
          }
        ]
      }
    ],
    children: [
      { id: 'id2200',
        name: '�������� (2 ��.)',
        catalogNumber: '4.9.12.16',
        images: [
          { imageURL: '4.9.12.16.jpg' }
        ]
      },
      { id: 'id2201',
        name: '�������',
        catalogNumber: '6.9.12.3',
        images: [
          { imageURL: '6.9.12.3.jpg' }
        ]
      },
      { id: 'id2202',
        name: '���',
        catalogNumber: '6.9.12.26',
        images: [
          { imageURL: '6.9.12.26.jpg' }
        ]
      },
      { id: 'id2203',
        name: '����� (2 ��.) ',
        catalogNumber: '6.9.12.6',
        images: [
          { imageURL: '6.9.12.6.jpg' }
        ]
      },
      { id: 'id2204',
        name: '������ (4 ��.)',
        catalogNumber: '6.9.12.13',
        images: [
          { imageURL: '6.9.12.13.jpg' }
        ]
      },
      { id: 'id2205',
        name: '������',
        catalogNumber: '6.9.12.14',
        images: [
          { imageURL: '6.9.12.14.jpg' }
        ]
      },
      { id: 'id2206',
        name: '������ (2 ��.)',
        catalogNumber: '6.9.12.18',
        images: [
          { imageURL: '6.9.12.18.jpg' }
        ]
      },
      { id: 'id2207',
        name: '������ (2 ��.)',
        catalogNumber: '6.9.12.20',
        images: [
          { imageURL: '6.9.12.20.jpg' }
        ]
      },
      { id: 'id2208',
        name: '������',
        catalogNumber: '6.9.12.54'
      },
      { id: 'id2209',
        name: '������',
        catalogNumber: '6.9.12.55'
      },
      { id: 'id2210',
        name: '��������� (2 ��.)',
        catalogNumber: '6.9.12.57'
      },
      { id: 'id2211',
        name: '������ (2 ��.)',
        catalogNumber: '6.9.12.58'
      },
      { id: 'id2212',
        name: '������ (2 ��.)',
        catalogNumber: '6.9.12.59'
      },
      { id: 'id2213',
        name: '�������',
        catalogNumber: '6.9.12.60'
      },
      { id: 'id2214',
        name: '������ (2 ��.)',
        catalogNumber: '6.9.12.62'
      },
      { id: 'id2215',
        name: '������',
        catalogNumber: '6.9.12.63'
      },
      { id: 'id2216',
        name: '�����-��������',
        catalogNumber: '6.9.12.66',
        images: [
          { imageURL: '6.9.12.66.jpg' }
        ]
      }
    ]
  },

  // 23
  { id: '23',
    name: '����� ����������� ����',
    catalogNumber: '8.10.1',
    images: [
      { imageURL: '8.10.1.jpg' }
    ],
    children: [
      { id: 'id2300',
        name: '������',
        catalogNumber: '4.10.1.2',
        images: [
          { imageURL: '4.10.1.2.jpg' }
        ]
      },
      { id: 'id2301',
        name: '������',
        catalogNumber: '8.10.1.3',
        images: [
          { imageURL: '4.10.1.3.jpg' }
        ]
      }
    ]
  },

  // 24
  { id: '24',
    name: '����� ��������� ����',
    catalogNumber: '6.10.4',
    images: [
      { imageURL: '6.10.4.jpg' }
    ]
  },

  // 25
  { id: '25',
    name: '����������� ��������',
    catalogNumber: '8.11.1.�',
    description: '����������� �������� (����� ������. ������. - �����)',
    images: [
      { imageURL: '8.11.1.l.jpg',
        mapMarkers: [
          { top: '10.5',
            left: '82.5',
            width: '8',
            height: '3',
            href: '25,1'
          },
          { top: '15.1',
            left: '92.5',
            width: '8',
            height: '3',
            href: '25,6'
          },
          { top: '17.7',
            left: '68.8',
            width: '8',
            height: '3',
            href: '25,3'
          },
          { top: '21.4',
            left: '68.8',
            width: '8',
            height: '3',
            href: '25,8'
          },
          { top: '52.9',
            left: '68',
            width: '8',
            height: '3',
            href: '25,7'
          },
          { top: '55.9',
            left: '68',
            width: '8',
            height: '3',
            href: '25,4'
          },
          { top: '59.7',
            left: '87',
            width: '8',
            height: '3',
            href: '25,7'
          },
          { top: '62.7',
            left: '87',
            width: '8',
            height: '3',
            href: '25,2'
          },
          { top: '69.8',
            left: '93.8',
            width: '8',
            height: '3',
            href: '25,9'
          },
          { top: '73.6',
            left: '93.8',
            width: '8',
            height: '3',
            href: '25,10'
          },
          { top: '38.8',
            left: '51.3',
            width: '7',
            height: '3',
            href: '26'
          },
          { top: '41.4',
            left: '6.3',
            width: '8',
            height: '3',
            href: '25,2'
          },
          { top: '36.4',
            left: '5.5',
            width: '6',
            height: '3',
            href: '25,0'
          },
          { top: '45.4',
            left: '6.3',
            width: '8',
            height: '3',
            href: '25,5'
          },
          { top: '79.3',
            left: '6.7',
            width: '8',
            height: '3',
            href: '25,7'
          },
          { top: '61.8',
            left: '31.5',
            width: '8',
            height: '3',
            href: '25,8'
          },
          { top: '57.1',
            left: '31.5',
            width: '8',
            height: '3',
            href: '25,3'
          },
          { top: '52.9',
            left: '31.8',
            width: '8',
            height: '3',
            href: '25,4'
          }
        ]
      }
    ],
    children: [
      { id: 'id2500',
        name: '����� �������������� (�����)',
        catalogNumber: '1.11.8',
        images: [
          { imageURL: '1.11.8.jpg' }
        ]
      },
      { id: 'id2501',
        name: '������',
        catalogNumber: '8.11.1.14',
        images: [
          { imageURL: '8.11.1.14.jpg' }
        ]
      },
      { id: 'id2502',
        name: '��������� (2 ��.)',
        catalogNumber: '8.11.1.16',
        images: [
          { imageURL: '8.11.1.16.jpg' }
        ]
      },
      { id: 'id2503',
        name: '������ (2 ��.)',
        catalogNumber: '4.11.1.18',
        images: [
          { imageURL: '4.11.1.18.jpg' }
        ]
      },
      { id: 'id2504',
        name: '��������� (2 ��.)',
        catalogNumber: '8.11.1.45'
      },
      { id: 'id2505',
        name: '������ (2 ��.)',
        catalogNumber: '8.11.1.46'
      },
      { id: 'id2506',
        name: '������',
        catalogNumber: '8.11.1.47'
      },
      { id: 'id2507',
        name: '������� (3 ��.)',
        catalogNumber: '8.11.1.48'
      },
      { id: 'id2508',
        name: '������� (2 ��.)',
        catalogNumber: '8.11.1.50'
      },
      { id: 'id2509',
        name: '��������� ����� (2 ��.)',
        catalogNumber: '8.11.1.55'
      },
      { id: 'id2510',
        name: '�����-��������',
        catalogNumber: '8.11.1.56'
      }
    ]
  },

  // 26
  { id: '26',
    name: '����',
    catalogNumber: '8.11.1.7',
    images: [
      { imageURL: '8.11.1.7.jpg',
        mapMarkers: [
          { top: '30',
            left: '11',
            width: '9',
            height: '3.5',
            href: '26,2'
          },
          { top: '34.9',
            left: '11',
            width: '9',
            height: '3.5',
            href: '26,0'
          },
          { top: '43.2',
            left: '59',
            width: '9',
            height: '3.5',
            href: '26,3'
          },
          { top: '91.6',
            left: '80.4',
            width: '9',
            height: '3.5',
            href: '26,2'
          },
          { top: '96',
            left: '80.2',
            width: '9',
            height: '3.5',
            href: '26,1'
          }
        ]
      }
    ],
    children: [
      { id: 'id2600',
        name: '�����',
        catalogNumber: '4.11.1.7.2',
        images: [
          { imageURL: '4.11.1.7.2.jpg' }
        ]
      },
      { id: 'id2601',
        name: '�����',
        catalogNumber: '8.11.1.7.3'
      },
      { id: 'id2602',
        name: '������ (2 ��.)',
        catalogNumber: '4.11.1.7.5',
        images: [
          { imageURL: '4.11.1.7.5.jpg' }
        ]
      },
      { id: 'id2603',
        name: '���� �����',
        catalogNumber: '6.11.1.7.6',
        images: [
          { imageURL: '6.11.1.7.6.jpg' }
        ]
      }
    ]
  },

  // 27
  { id: '27',
    name: '����������� ��������',
    catalogNumber: '8.12.1�',
    description: '����������� �������� (������-����� ������. ������. -����. ����)',
    images: [
      { imageURL: '8.12.1l.jpg',
        mapMarkers: [
          { top: '7.6',
            left: '81.3',
            width: '5.5',
            height: '2.6',
            href: '27,2'
          },
          { top: '4.7',
            left: '92',
            width: '5.5',
            height: '2.6',
            href: '27,6'
          },
          { top: '16.6',
            left: '74.8',
            width: '5.5',
            height: '2.6',
            href: '27,3'
          },
          { top: '19.8',
            left: '74.8',
            width: '5.5',
            height: '2.6',
            href: '27,8'
          },
          { top: '45.4',
            left: '79.9',
            width: '5.5',
            height: '2.6',
            href: '27,7'
          },
          { top: '47.9',
            left: '80.4',
            width: '5.5',
            height: '2.6',
            href: '27,4'
          },
          { top: '45.5',
            left: '94.5',
            width: '5.5',
            height: '2.6',
            href: '27,7'
          },
          { top: '48.2',
            left: '94.5',
            width: '5.5',
            height: '2.6',
            href: '27,1'
          },
          { top: '50.4',
            left: '87.7',
            width: '5.5',
            height: '2.6',
            href: '27,9'
          },
          { top: '76.5',
            left: '92.1',
            width: '5.5',
            height: '2.6',
            href: '27,10'
          },
          { top: '43.8',
            left: '61.2',
            width: '5.5',
            height: '2.6',
            href: '28'
          },
          { top: '40.9',
            left: '49.6',
            width: '5.5',
            height: '2.6',
            href: '27,0'
          },
          { top: '53.3',
            left: '14.6',
            width: '5.5',
            height: '2.6',
            href: '27,0'
          },
          { top: '62.5',
            left: '4.1',
            width: '5.5',
            height: '2.6',
            href: '27,1'
          },
          { top: '65.7',
            left: '4.1',
            width: '5.5',
            height: '2.6',
            href: '27,5'
          },
          { top: '62.7',
            left: '27.9',
            width: '5.5',
            height: '2.6',
            href: '27,4'
          },
          { top: '66.3',
            left: '27.9',
            width: '5.5',
            height: '2.6',
            href: '27,3'
          },
          { top: '70.2',
            left: '27.9',
            width: '5.5',
            height: '2.6',
            href: '27,8'
          },
          { top: '94',
            left: '13.3',
            width: '5.5',
            height: '2.6',
            href: '27,7'
          }
        ]
      }
    ],
    children: [
      { id: 'id2700',
        name: '����� �������������� (�����) (2 ��.)',
        catalogNumber: '1.11.12'
      },
      { id: 'id2701',
        name: '��������� (2 ��.)',
        catalogNumber: '8.12.1.16'
      },
      { id: 'id2702',
        name: '������',
        catalogNumber: '8.11.1.14',
        images: [
          { imageURL: '8.11.1.14.jpg' }
        ]
      },
      { id: 'id2703',
        name: '������ (2 ��.)',
        catalogNumber: '4.11.1.18'
      },
      { id: 'id2704',
        name: '��������� (2 ��.)',
        catalogNumber: '8.11.1.45'
      },
      { id: 'id2705',
        name: '������ (2 ��.)',
        catalogNumber: '8.11.1.46'
      },
      { id: 'id2706',
        name: '������',
        catalogNumber: '8.11.1.47'
      },
      { id: 'id2707',
        name: '������� (3 ��.)',
        catalogNumber: '8.11.1.48'
      },
      { id: 'id2708',
        name: '������� (2 ��.)',
        catalogNumber: '8.11.1.50'
      },
      { id: 'id2709',
        name: '��������� ����� (2 ��.)',
        catalogNumber: '8.11.1.55'
      },
      { id: 'id2710',
        name: '�����-��������',
        catalogNumber: '8.11.1.56'
      }
    ]
  },

  // 28
  { id: '28',
    name: '����',
    catalogNumber: '8.12.1.7',
    images: [
      { imageURL: '8.12.1.7.jpg',
        mapMarkers: [
          { top: '30',
            left: '11',
            width: '9',
            height: '3.5',
            href: '26,2'
          },
          { top: '34.9',
            left: '11',
            width: '9',
            height: '3.5',
            href: '26,0'
          },
          { top: '39.2',
            left: '54.6',
            width: '9',
            height: '3.5',
            href: '28,3'
          },
          { top: '91.6',
            left: '80.4',
            width: '9',
            height: '3.5',
            href: '26,2'
          },
          { top: '96',
            left: '80.2',
            width: '9',
            height: '3.5',
            href: '26,1'
          }
        ]
      }
    ],
    children: [
      { id: 'id2800',
        name: '�����',
        catalogNumber: '8.11.1.7.3',
        images: [
          { imageURL: '8.11.1.7.3.jpg' }
        ]
      },
      { id: 'id2801',
        name: '�����',
        catalogNumber: '4.11.1.7.2'
      },
      { id: 'id2802',
        name: '������ (2 ��.)',
        catalogNumber: '4.11.1.7.5'
      },
      { id: 'id2803',
        name: '���� �����',
        catalogNumber: '6.12.1.7.6',
        images: [
          { imageURL: '6.12.1.7.6.jpg' }
        ]
      }
    ]
  },

  // 29
  { id: '29',
    name: '����',
    catalogNumber: '4.14.1',
    images: [
      { imageURL: '4.14.1.jpg' }
    ]
  },

  // 30
  { id: '30',
    name: '�������',
    catalogNumber: '4.14.2',
    images: [
      { imageURL: '4.14.2.jpg',
        mapMarkers: [
          { top: '3.8',
            left: '73.4',
            width: '7.8',
            height: '2.8',
            href: '30,15'
          },
          { top: '6.5',
            left: '73.4',
            width: '7.8',
            height: '2.8',
            href: '30,16'
          },
          { top: '9.2',
            left: '73.4',
            width: '7.8',
            height: '2.8',
            href: '30,17'
          },
          { top: '8.9',
            left: '42.1',
            width: '7.2',
            height: '2.8',
            href: '30,2'
          },
          { top: '8.7',
            left: '50.3',
            width: '7.4',
            height: '2.8',
            href: '30,9'
          },
          { top: '8.7',
            left: '58.9',
            width: '7.4',
            height: '2.8',
            href: '30,1'
          },
          { top: '9.9',
            left: '82.9',
            width: '7.4',
            height: '2.8',
            href: '30,12'
          },
          { top: '11.1',
            left: '93.4',
            width: '7.4',
            height: '2.8',
            href: '30,6'
          },
          { top: '15',
            left: '93.2',
            width: '7.4',
            height: '2.8',
            href: '30,5'
          },
          { top: '18.7',
            left: '93.2',
            width: '7.4',
            height: '2.8',
            href: '30,7'
          },
          { top: '22.5',
            left: '95.7',
            width: '7.4',
            height: '2.8',
            href: '30,10'
          },
          { top: '33',
            left: '31.4',
            width: '7.4',
            height: '2.8',
            href: '30,3'
          },
          { top: '37.8',
            left: '32.3',
            width: '7.4',
            height: '2.8',
            href: '30,14'
          },
          { top: '94.8',
            left: '33.9',
            width: '7.4',
            height: '2.8',
            href: '30,13'
          },
          { top: '94.2',
            left: '89.4',
            width: '7.4',
            height: '2.8',
            href: '30,4'
          },
          { top: '89.5',
            left: '91.8',
            width: '7.4',
            height: '2.8',
            href: '30,0'
          },
          { top: '85.5',
            left: '94.7',
            width: '7.4',
            height: '2.8',
            href: '30,8'
          },
          { top: '81.4',
            left: '96',
            width: '7.4',
            height: '2.8',
            href: '30,11'
          }
        ]
      }
    ],
    children: [
      { id: 'id3000',
        name: '������� (3-� � 4-� ����) (24 ��.)',
        catalogNumber: '4.14.2.1',
        images: [
          { imageURL: '4.14.2.1.jpg' }
        ]
      },
      { id: 'id3001',
        name: '������� (5-� � 6-� ����) (24 ��.)',
        catalogNumber: '4.14.2.2',
        images: [
          { imageURL: '4.14.2.2.jpg' }
        ]
      },
      { id: 'id3002',
        name: '������� (7-� � 8-� ����) (32 ��.)',
        catalogNumber: '4.14.2.3',
        images: [
          { imageURL: '4.14.2.3.jpg' }
        ]
      },
      { id: 'id3003',
        name: '������� (9-� ���) (36 ��.)',
        catalogNumber: '4.14.2.4',
        images: [
          { imageURL: '4.14.2.4.jpg' }
        ]
      },
      { id: 'id3004',
        name: '�����������',
        catalogNumber: '4.14.2.5',
        images: [
          { imageURL: '4.14.2.5.jpg' }
        ]
      },
      { id: 'id3005',
        name: '������� (1-� ���) (8 ��.)',
        catalogNumber: '4.14.2.9'
      },
      { id: 'id3006',
        name: '������� (1-� ���) (8 ��.)',
        catalogNumber: '4.14.2.10'
      },
      { id: 'id3007',
        name: '������� (2-� ���) (16 ��.)',
        catalogNumber: '4.14.2.11'
      },
      { id: 'id3008',
        name: '������� (3-� � 4-� ����) (24 ��.)',
        catalogNumber: '4.14.2.12',
        images: [
          { imageURL: '4.14.2.12.jpg' }
        ]
      },
      { id: 'id3009',
        name: '������� (5-� � 6-� ����) (24 ��.)',
        catalogNumber: '4.14.2.13',
        images: [
          { imageURL: '4.14.2.13.jpg' }
        ]
      },
      { id: 'id3010',
        name: '������ (96 ��.)',
        catalogNumber: '4.14.2.15',
        images: [
          { imageURL: '4.14.2.15.jpg' }
        ]
      },
      { id: 'id3011',
        name: '������ (64 ��.)',
        catalogNumber: '4.14.2.16',
        images: [
          { imageURL: '4.14.2.16.jpg' }
        ]
      },
      { id: 'id3012',
        name: '������ (96 ��.)',
        catalogNumber: '4.14.2.17',
        images: [
          { imageURL: '4.14.2.17.jpg' }
        ]
      },
      { id: 'id3013',
        name: '������ (2 ��.)',
        catalogNumber: '4.14.2.24',
        images: [
          { imageURL: '4.14.2.24.jpg' }
        ]
      },
      { id: 'id3014',
        name: '������ (64 ��.)',
        catalogNumber: '4.14.2.18',
        images: [
          { imageURL: '4.14.2.18.jpg' }
        ]
      },
      { id: 'id3015',
        name: '���� (352 ��.)',
        catalogNumber: '4.14.2.29'
      },
      { id: 'id3016',
        name: '����� (352 ��.)',
        catalogNumber: '4.14.2.30'
      },
      { id: 'id3017',
        name: '����� (352 ��.)',
        catalogNumber: '4.14.2.31'
      }
    ]
  },

  // 31
  { id: '31',
    name: '����� ��������� (4 ��.)',
    catalogNumber: '4.14.6',
    images: [
      { imageURL: '4.14.6.jpg',
        mapMarkers: [
          { top: '6.6',
            left: '79.7',
            width: '7.8',
            height: '4',
            href: '31,8'
          },
          { top: '11.8',
            left: '79.8',
            width: '7.8',
            height: '4',
            href: '31,10'
          },
          { top: '17',
            left: '79.8',
            width: '7.8',
            height: '4',
            href: '31,5'
          },
          { top: '34.6',
            left: '80.9',
            width: '7.8',
            height: '4',
            href: '31,12'
          },
          { top: '6.5',
            left: '64.8',
            width: '7.8',
            height: '4',
            href: '31,9'
          },
          { top: '6.5',
            left: '54.7',
            width: '7.8',
            height: '4',
            href: '31,6'
          },
          { top: '6.5',
            left: '45.3',
            width: '7.8',
            height: '4',
            href: '31,7'
          },
          { top: '16.1',
            left: '46.2',
            width: '7.8',
            height: '4',
            href: '31,4'
          },
          { top: '12.7',
            left: '4.8',
            width: '8.5',
            height: '4',
            href: '31,1'
          },
          { top: '18',
            left: '4.4',
            width: '7.8',
            height: '4',
            href: '31,0'
          },
          { top: '24.3',
            left: '4.6',
            width: '7.8',
            height: '4',
            href: '31,11'
          },
          { top: '85.9',
            left: '5.2',
            width: '7.8',
            height: '4',
            href: '31,2'
          },
          { top: '86',
            left: '15.8',
            width: '7.8',
            height: '4',
            href: '31,4'
          },
          { top: '85.5',
            left: '24.6',
            width: '7.8',
            height: '4',
            href: '31,3'
          }
        ]
      }
    ],
    children: [
      { id: 'id3100',
        name: '����� (8 ��.)',
        catalogNumber: '4.14.6.2',
        images: [
          { imageURL: '4.14.6.2.jpg' }
        ]
      },
      { id: 'id3101',
        name: '����� (4 ��.)',
        catalogNumber: '4.14.6.5.�',
        images: [
          { imageURL: '4.14.6.5.l.jpg' }
        ]
      },
      { id: 'id3102',
        name: '��� (4 ��.)',
        catalogNumber: '4.14.6.6',
        images: [
          { imageURL: '4.14.6.6.jpg' }
        ]
      },
      { id: 'id3103',
        name: '������ (12 ��.)',
        catalogNumber: '4.14.6.7',
        images: [
          { imageURL: '4.14.6.7.jpg' }
        ]
      },
      { id: 'id3104',
        name: '������ (16 ��.)',
        catalogNumber: '4.14.6.8',
        images: [
          { imageURL: '4.14.6.8.jpg' }
        ]
      },
      { id: 'id3105',
        name: '����� (4 ��.)',
        catalogNumber: '4.14.6.9',
        images: [
          { imageURL: '4.14.6.9.jpg' }
        ]
      },
      { id: 'id3106',
        name: '������ (4 ��.)',
        catalogNumber: '4.14.6.12',
        images: [
          { imageURL: '4.14.6.12.jpg' }
        ]
      },
      { id: 'id3107',
        name: '������ (4 ��.)',
        catalogNumber: '4.14.6.24'
      },
      { id: 'id3108',
        name: '������ (4 ��.)',
        catalogNumber: '4.14.6.25'
      },
      { id: 'id3109',
        name: '������ (8 ��.)',
        catalogNumber: '4.14.6.27',
        images: [
          { imageURL: '4.14.6.27.jpg' }
        ]
      },
      { id: 'id3110',
        name: '������ (4 ��.)',
        catalogNumber: '4.14.6.29',
        images: [
          { imageURL: '4.14.6.29.jpg' }
        ]
      },
      { id: 'id3111',
        name: '��������� (8 ��.)',
        catalogNumber: '4.14.6.31'
      },
      { id: 'id3112',
        name: '�����-�������� (4 ��.)',
        catalogNumber: '4.14.6.36'
      }
    ]
  },

  // 32
  { id: '32',
    name: '����� ��������������� (2 ��.)',
    catalogNumber: '4.14.8',
    images: [
      { imageURL: '4.14.8.jpg',
        mapMarkers: [
          { top: '50.6',
            left: '41.7',
            width: '15',
            height: '3',
            href: '32,3'
          },
          { top: '56.5',
            left: '48.5',
            width: '15',
            height: '3',
            href: '32,4'
          },
          { top: '56.5',
            left: '71.5',
            width: '15',
            height: '3',
            href: '32,5'
          },
          { top: '56.5',
            left: '90.5',
            width: '15',
            height: '3',
            href: '32,0'
          },
          { top: '92.5',
            left: '67.7',
            width: '15',
            height: '3',
            href: '32,2'
          },
          { top: '92.9',
            left: '87.9',
            width: '15',
            height: '3',
            href: '32,1'
          }
        ]
      }
    ],
    children: [
      { id: 'id3200',
        name: '����� (2 ��.)',
        catalogNumber: '4.14.8.1',
        images: [
          { imageURL: '4.14.8.1.jpg' }
        ]
      },
      { id: 'id3201',
        name: '����� (2 ��.)',
        catalogNumber: '4.14.8.2',
        images: [
          { imageURL: '4.14.8.2.jpg' }
        ]
      },
      { id: 'id3202',
        name: '��� (2 ��.)',
        catalogNumber: '4.14.8.3',
        images: [
          { imageURL: '4.14.8.3.jpg' }
        ]
      },
      { id: 'id3203',
        name: '������ (2 ��.)',
        catalogNumber: '4.14.8.6',
        images: [
          { imageURL: '4.14.8.6.jpg' }
        ]
      },
      { id: 'id3204',
        name: '������ (12 ��.)',
        catalogNumber: '4.14.8.7',
        images: [
          { imageURL: '4.14.8.7.jpg' }
        ]
      },
      { id: 'id3205',
        name: '��������� (4 ��.)',
        catalogNumber: '4.14.8.10'
      }
    ]
  },

  // 33
  { id: '33',
    name: '������ ������������',
    catalogNumber: '4.14.3',
    images: [
      { imageURL: '4.14.3.jpg' }
    ]
  },

  // 34
  { id: '34',
    name: '������ �������',
    catalogNumber: '4.14.4.(1)',
    images: [
      { imageURL: '4.14.4.(1).jpg' }
    ]
  },

  // 35
  { id: '35',
    name: '������ �������',
    catalogNumber: '4.14.4.��',
    images: [
      { imageURL: '4.14.4.(1).jpg' }
    ]
  },

  // 36
  { id: '36',
    name: '�����',
    catalogNumber: '4.14.1.�',
    images: [
      { imageURL: '4.14.1.l.jpg',
        mapMarkers: [
          { top: '21.6',
            left: '89',
            width: '20',
            height: '4',
            href: '36,0'
          },
          { top: '51.1',
            left: '18',
            width: '20',
            height: '4',
            href: '36,5'
          },
          { top: '61.6',
            left: '18.8',
            width: '22',
            height: '4',
            href: '36,4'
          },
          { top: '70.1',
            left: '18.8',
            width: '22',
            height: '4',
            href: '36,2'
          },
          { top: '78.1',
            left: '17.8',
            width: '21',
            height: '4',
            href: '36,1'
          },
          { top: '86.6',
            left: '18.8',
            width: '22',
            height: '4',
            href: '36,3'
          }
        ]
      }
    ],
    children: [
      { id: 'id3600',
        name: '�������������� �����',
        catalogNumber: '4.14.4.1.8.�',
        images: [
          { imageURL: '4.14.4.1.8.l.jpg' }
        ]
      },
      { id: 'id3601',
        name: '�������������� �����',
        catalogNumber: '4.14.4.1.9.�',
        images: [
          { imageURL: '4.14.4.1.9.l.jpg' }
        ]
      },
      { id: 'id3602',
        name: '�������������� �����',
        catalogNumber: '4.14.4.1.10.�',
        images: [
          { imageURL: '4.14.4.1.10.l.jpg' }
        ]
      },
      { id: 'id3603',
        name: '�������������� �����',
        catalogNumber: '4.14.4.1.11.�',
        images: [
          { imageURL: '4.14.4.1.11.l.jpg' }
        ]
      },
      { id: 'id3604',
        name: '�������������� �����',
        catalogNumber: '4.14.4.1.12.�',
        images: [
          { imageURL: '4.14.4.1.12.l.jpg' }
        ]
      },
      { id: 'id3605',
        name: '���� �������������� (10 ��.)',
        catalogNumber: '4.14.4.1.24',
        images: [
          { imageURL: '4.14.4.1.24.jpg' }
        ]
      }
    ]
  },

  // 37
  { id: '37',
    name: '�����',
    catalogNumber: '4.14.4.2',
    images: [
      { imageURL: '4.14.4.2.jpg',
        mapMarkers: [
          { top: '69.8',
            left: '13.2',
            width: '16.5',
            height: '3.5',
            href: '37,3'
          },
          { top: '74.9',
            left: '13.2',
            width: '16.5',
            height: '3.5',
            href: '37,0'
          },
          { top: '80.3',
            left: '13.4',
            width: '17',
            height: '3.5',
            href: '37,1'
          },
          { top: '61.8',
            left: '88.5',
            width: '17',
            height: '3.5',
            href: '37,2'
          }
        ]
      }
    ],
    children: [
      { id: 'id3700',
        name: '�������������� �����',
        catalogNumber: '4.14.4.2.5',
        images: [
          { imageURL: '4.14.4.2.5.jpg' }
        ]
      },
      { id: 'id3701',
        name: '�������������� �����',
        catalogNumber: '4.14.4.2.6',
        images: [
          { imageURL: '4.14.4.2.6.jpg' }
        ]
      },
      { id: 'id3702',
        name: '�������������� �����',
        catalogNumber: '4.14.4.2.7',
        images: [
          { imageURL: '4.14.4.2.7.jpg' }
        ]
      },
      { id: 'id3703',
        name: '�������������� �����',
        catalogNumber: '4.14.4.2.8',
        images: [
          { imageURL: '4.14.4.2.8.jpg' }
        ]
      }
    ]
  },

  // 38
  { id: '38',
    name: '���� � �������',
    catalogNumber: '8.20.3',
    images: [
      { imageURL: '8.20.3.jpg',
        mapMarkers: [
          { top: '29.4',
            left: '5.8',
            width: '9.5',
            height: '5',
            href: '38,6'
          },
          { top: '35.4',
            left: '5.8',
            width: '9.5',
            height: '5',
            href: '38,5'
          },
          { top: '41.4',
            left: '5.8',
            width: '9.5',
            height: '5',
            href: '38,0'
          },
          { top: '41.4',
            left: '94.5',
            width: '9.5',
            height: '5',
            href: '38,0'
          },
          { top: '98.8',
            left: '94.9',
            width: '9.5',
            height: '5',
            href: '38,1'
          },
          { top: '99.7',
            left: '21.6',
            width: '9.5',
            height: '5',
            href: '38,1'
          },
          { top: '99',
            left: '79.5',
            width: '9.5',
            height: '5',
            href: '38,3'
          },
          { top: '99.4',
            left: '34.2',
            width: '9.5',
            height: '5',
            href: '38,3'
          },
          { top: '99.2',
            left: '8.1',
            width: '9.5',
            height: '5',
            href: '38,2'
          },
          { top: '71.4',
            left: '41',
            width: '9.5',
            height: '5',
            href: '38,4'
          },
          { top: '71.4',
            left: '68.7',
            width: '9.5',
            height: '5',
            href: '38,4'
          }
        ]
      }
    ],
    children: [
      { id: 'id3800',
        name: '��������� (2 ��.)',
        catalogNumber: '8.20.3.45',
        images: [
          { imageURL: '8.20.3.45.jpg' }
        ]
      },
      { id: 'id3801',
        name: '������ (2 ��.)',
        catalogNumber: '8.20.3.46',
        images: [
          { imageURL: '8.20.3.46.jpg' }
        ]
      },
      { id: 'id3802',
        name: '������',
        catalogNumber: '8.20.3.47'
      },
      { id: 'id3803',
        name: '������� (3 ��.)',
        catalogNumber: '8.20.3.48'
      },
      { id: 'id3804',
        name: '������� (2 ��.)',
        catalogNumber: '8.20.3.50'
      },
      { id: 'id3805',
        name: '��������� ����� (2 ��.)',
        catalogNumber: '8.20.3.55',
        images: [
          { imageURL: '8.20.3.55.jpg' }
        ]
      },
      { id: 'id3806',
        name: '�����-��������',
        catalogNumber: '8.20.3.56',
        images: [
          { imageURL: '8.20.3.56.jpg' }
        ]
      }
    ]
  },

  // 39
  { id: '39',
    name: '��������',
    catalogNumber: '8.20.5',
    images: [
      { imageURL: '8.20.5.jpg' }
    ]
  },

  // 40
  { id: '40',
    name: '������',
    catalogNumber: '8.20.1',
    images: [
      { imageURL: '8.20.1.jpg',
        mapMarkers: [
          { top: '20',
            left: '21.8',
            width: '9',
            height: '4.5',
            href: '40,0'
          },
          { top: '18.9',
            left: '94.3',
            width: '9.5',
            height: '4',
            href: '40,4'
          },
          { top: '86.3',
            left: '79.3',
            width: '9.5',
            height: '4',
            href: '40,2'
          },
          { top: '90.6',
            left: '79.7',
            width: '9.5',
            height: '4',
            href: '40,3'
          },
          { top: '55',
            left: '9.4',
            width: '9.5',
            height: '4',
            href: '40,0,8'
          },
          { top: '50.3',
            left: '9.3',
            width: '9.5',
            height: '4',
            href: '40,0,6'
          },
          { top: '44.9',
            left: '8.3',
            width: '9.5',
            height: '4',
            href: '40,1'
          },
          { top: '35.2',
            left: '19.3',
            width: '9.5',
            height: '4',
            href: '40,0,7'
          }
        ]
      }
    ],
    children: [
      { id: 'id4000',
        name: '������ ������ (4 ��.)',
        catalogNumber: '8.20.1.2',
        images: [
          { imageURL: '8.20.1.2.jpg',
            mapMarkers: [
              { top: '4.6',
                left: '63',
                width: '25',
                height: '4',
                href: '40,0,2'
              },
              { top: '13',
                left: '83.7',
                width: '25',
                height: '4',
                href: '40,0,4'
              },
              { top: '17',
                left: '84.7',
                width: '25',
                height: '4',
                href: '40,0,5'
              },
              { top: '56',
                left: '86.2',
                width: '25',
                height: '4',
                href: '40,0,1'
              },
              { top: '73.6',
                left: '34.2',
                width: '25',
                height: '4',
                href: '40,0,0'
              },
              { top: '92',
                left: '35.2',
                width: '25',
                height: '4',
                href: '40,0,3'
              }
            ]
          }
        ],
        children: [
          { id: 'id400000',
            name: '������ (2 ��.)',
            catalogNumber: '8.20.1.2.54',
            images: [
              { imageURL: '8.20.1.2.54.jpg' }
            ]
          },
          { id: 'id400001',
            name: '��������� (2 ��.)',
            catalogNumber: '8.20.1.2.57',
            images: [
              { imageURL: '8.20.1.2.57.jpg' }
            ]
          },
          { id: 'id400002',
            name: '��������� (2 ��.)',
            catalogNumber: '8.20.1.2.59',
            images: [
              { imageURL: '8.20.1.2.59.jpg' }
            ]
          },
          { id: 'id400003',
            name: '������ (2 ��.)',
            catalogNumber: '8.20.1.2.60',
            images: [
              { imageURL: '8.20.1.2.60.jpg' }
            ]
          },
          { id: 'id400004',
            name: '�����-��������',
            catalogNumber: '8.20.1.2.62',
            images: [
              { imageURL: '8.20.1.2.62.jpg' }
            ]
          },
          { id: 'id400005',
            name: '������ (2 ��.)',
            catalogNumber: '8.20.1.2.63',
            images: [
              { imageURL: '8.20.1.2.63.jpg' }
            ]
          },
          { id: 'id400006',
            name: '������ ��.���������',
            catalogNumber: '8.20.1.49',
            images: [
              { imageURL: '8.20.1.49.jpg' }
            ]
          },
          { id: 'id400007',
            name: '����������� ������������ (80 �)',
            catalogNumber: '8.20.1.51'
          },
          { id: 'id400008',
            name: '����������������',
            catalogNumber: '8.20.1.60',
            images: [
              { imageURL: '8.20.1.60.jpg' }
            ]
          }
        ]
      },
      { id: 'id4001',
        name: '����������',
        catalogNumber: '8.20.1.4',
        images: [
          { imageURL: '8.20.1.4.jpg' }
        ]
      },
      { id: 'id4002',
        name: '������ ������� (864 ��.)',
        catalogNumber: '8.20.1.25',
        images: [
          { imageURL: '8.20.1.25.jpg' }
        ]
      },
      { id: 'id4003',
        name: '������ �������� (432 ��.)',
        catalogNumber: '8.20.1.26',
        images: [
          { imageURL: '8.20.1.26.jpg' }
        ]
      },
      { id: 'id4004',
        name: '����� (432 ��.)',
        catalogNumber: '8.20.1.27',
        images: [
          { imageURL: '8.20.1.27.jpg' }
        ]
      }
    ]
  },

  // 41
  { id: '41',
    name: '���������� ������ �������',
    catalogNumber: '6.18',
    images: [
      { imageURL: '6.18.jpg',
        mapMarkers: [
          { top: '94',
            left: '65.5',
            width: '13',
            height: '6',
            href: '41,1'
          },
          { top: '92',
            left: '88.8',
            width: '13',
            height: '6',
            href: '41,0'
          }
        ]
      }
    ],
    children: [
      { id: 'id4100',
        name: '���������� ������',
        catalogNumber: '6.18.48',
        images: [
          { imageURL: '6.18.48.jpg' }
        ]
      },
      { id: 'id4100',
        name: '��������� (2 ��.)',
        catalogNumber: '6.18.52',
        images: [
          { imageURL: '6.18.52.jpg' }
        ]
      }
    ]
  },

  // 42
  { id: '42',
    name: '����������� �������',
    catalogNumber: '6.46',
    images: [
      { imageURL: '6.46.jpg',
        mapMarkers: [
          { top: '31.8',
            left: '4',
            width: '6.5',
            height: '4.5',
            href: '43'
          },
          { top: '77.8',
            left: '26.5',
            width: '6.5',
            height: '4.5',
            href: '43'
          },
          { top: '19.2',
            left: '32.8',
            width: '7',
            height: '4.5',
            href: '54'
          },
          { top: '40.5',
            left: '66.5',
            width: '6.5',
            height: '4.5',
            href: '47'
          },
          { top: '26.2',
            left: '81',
            width: '6.5',
            height: '4.5',
            href: '47'
          },
          { top: '14.9',
            left: '63.5',
            width: '6.5',
            height: '4.5',
            href: '48'
          },
          { top: '68.1',
            left: '63.3',
            width: '6.5',
            height: '4.5',
            href: '48'
          },
          { top: '12.7',
            left: '80.8',
            width: '6.5',
            height: '4.5',
            href: '52'
          },
          { top: '26.2',
            left: '88.1',
            width: '6.5',
            height: '4.5',
            href: '56'
          },
          { top: '31.5',
            left: '81.5',
            width: '7',
            height: '4.5',
            href: '57'
          },
          { top: '88.2',
            left: '30.3',
            width: '7',
            height: '4.5',
            href: '49'
          },
          { top: '73.7',
            left: '49.8',
            width: '7',
            height: '4.5',
            href: '49'
          },
          { top: '70.8',
            left: '79.8',
            width: '7',
            height: '4.5',
            href: '49'
          },
          { top: '88.2',
            left: '4.3',
            width: '7.5',
            height: '4.5',
            href: '45'
          },
          { top: '88.7',
            left: '14.3',
            width: '8.5',
            height: '5',
            href: '50'
          },
          { top: '80.5',
            left: '81',
            width: '8.5',
            height: '5',
            href: '53'
          },
          { top: '52.7',
            left: '95.9',
            width: '7',
            height: '4.5',
            href: '58'
          },
          { top: '46.4',
            left: '96.7',
            width: '6',
            height: '4.5',
            href: '46'
          },
          { top: '97.1',
            left: '63.7',
            width: '6.5',
            height: '4.5',
            href: '44'
          }
        ]
      }
    ]
  },

  // 43
  { id: '43',
    name: '���������� ���������',
    catalogNumber: '2.46.1',
    images: [
      { imageURL: '2.46.1.jpg',
        mapMarkers: [
          { top: '17.2',
            left: '46.6',
            width: '10.5',
            height: '4.5',
            href: '43,0'
          }
        ]
      }
    ],
    children: [
      { id: 'id4300',
        name: '�����-�������',
        catalogNumber: '2.46.1.31',
        images: [
          { imageURL: '2.46.1.31.jpg' }
        ]
      }
    ]
  },

  // 44
  { id: '44',
    name: '����� ������� (43 ��.)',
    catalogNumber: '2.46.2',
    images: [
      { imageURL: '2.46.2.jpg' }
    ]
  },

  // 45
  { id: '45',
    name: '����� �������',
    catalogNumber: '2.46.2.01',
    images: [
      { imageURL: '2.46.2.01.jpg' }
    ]
  },

  // 46
  { id: '46',
    name: '�������',
    catalogNumber: '6.46.4',
    images: [
      { imageURL: '6.46.4.jpg' }
    ]
  },

  // 47
  { id: '47',
    name: '����� ������� ������������ (3 ��.)',
    catalogNumber: '2.46.6',
    images: [
      { imageURL: '2.46.6.jpg' }
    ]
  },

  // 48
  { id: '48',
    name: '����� ���������',
    catalogNumber: '2.46.24',
    images: [
      { imageURL: '2.46.24.jpg' }
    ]
  },

  // 49
  { id: '49',
    name: '����� ������������ (16 ��.)',
    catalogNumber: '2.46.12',
    images: [
      { imageURL: '2.46.12.jpg' }
    ]
  },

  // 50
  { id: '50',
    name: '����� ������������ (2 ��.)',
    catalogNumber: '2.46.12.01',
    images: [
      { imageURL: '2.46.12.01.jpg' }
    ]
  },

  // 51
  { id: '51',
    name: '�������',
    catalogNumber: '6.46.14',
    images: [
      { imageURL: '6.46.14.jpg' }
    ]
  },

  // 52
  { id: '52',
    name: '����� (132 ��.)',
    catalogNumber: '2.46.15',
    images: [
      { imageURL: '2.46.15.jpg' }
    ]
  },

  // 53
  { id: '53',
    name: '����� (12 ��.)',
    catalogNumber: '2.46.15.01',
    images: [
      { imageURL: '2.46.15.01.jpg' }
    ]
  },

  // 54
  { id: '54',
    name: '������-������� (5 ��.)',
    catalogNumber: '6.46.18',
    images: [
      { imageURL: '6.46.18.jpg',
        mapMarkers: [
          { top: '52.6',
            left: '10.8',
            width: '14.5',
            height: '2.4',
            href: '54,5'
          },
          { top: '73.5',
            left: '9',
            width: '12.5',
            height: '2.4',
            href: '55'
          },
          { top: '63.4',
            left: '89.1',
            width: '12.5',
            height: '2.4',
            href: '54,1'
          },
          { top: '66.8',
            left: '89.3',
            width: '12.5',
            height: '2.4',
            href: '54,3'
          },
          { top: '74',
            left: '90.4',
            width: '13',
            height: '2.4',
            href: '54,4'
          },
          { top: '82.5',
            left: '89.6',
            width: '12.5',
            height: '2.4',
            href: '54,2'
          }
        ]
      }
    ],
    children: [
      { id: 'id5400',
        name: '����������� (5 ��.)',
        catalogNumber: '6.46.18.2',
        images: [
          { imageURL: '6.46.18.2.jpg' }
        ]
      },
      { id: 'id5401',
        name: '������ ������ (5 ��.)',
        catalogNumber: '6.46.18.5',
        images: [
          { imageURL: '6.46.18.5.jpg' }
        ]
      },
      { id: 'id5402',
        name: '������ (5 ��.)',
        catalogNumber: '6.46.18.7',
        images: [
          { imageURL: '6.46.18.7.jpg' }
        ]
      },
      { id: 'id5403',
        name: '����� (10 ��.)',
        catalogNumber: '6.46.18.9',
        images: [
          { imageURL: '6.46.18.9.jpg' }
        ]
      },
      { id: 'id5404',
        name: '��������� (10 ��.)',
        catalogNumber: '6.46.18.11'
      },
      { id: 'id5405',
        name: '�������� (2 ��.)',
        catalogNumber: '6.46.18.26',
        images: [
          { imageURL: '6.46.18.26.jpg' }
        ]
      }
    ]
  },

  // 55
  { id: '55',
    name: '����������� (5 ��.)',
    catalogNumber: '6.46.18.2',
    images: [
      { imageURL: '6.46.18.2.jpg',
        mapMarkers: [
          { top: '15.4',
            left: '7.8',
            width: '12',
            height: '3.5',
            href: '55,8'
          },
          { top: '15',
            left: '37.3',
            width: '12',
            height: '3.5',
            href: '55,7'
          },
          { top: '13.5',
            left: '88.8',
            width: '12',
            height: '3.5',
            href: '55,0'
          },
          { top: '83.6',
            left: '61.3',
            width: '12',
            height: '3.5',
            href: '55,2'
          },
          { top: '87.6',
            left: '62',
            width: '12',
            height: '3.5',
            href: '55,6'
          },
          { top: '91.2',
            left: '62.3',
            width: '12',
            height: '3.5',
            href: '55,5'
          },
          { top: '95',
            left: '63.4',
            width: '12.2',
            height: '3.5',
            href: '55,3'
          },
          { top: '71.3',
            left: '17.9',
            width: '13',
            height: '3.5',
            href: '55,1'
          },
          { top: '80.7',
            left: '17.7',
            width: '12.5',
            height: '3.5',
            href: '55,4'
          }
        ]
      }
    ],
    children: [
      { id: 'id5500',
        name: '������� ������� (5 ��.)',
        catalogNumber: '6.46.18.2.2',
        images: [
          { imageURL: '6.46.18.2.2.jpg' }
        ]
      },
      { id: 'id5501',
        name: '������� ������� (5 ��.)',
        catalogNumber: '6.46.18.2.3.01',
        images: [
          { imageURL: '6.46.18.2.3.01.jpg' }
        ]
      },
      { id: 'id5502',
        name: '����� (35 ��.)',
        catalogNumber: '6.46.18.2.7',
        images: [
          { imageURL: '6.46.18.2.7.jpg' }
        ]
      },
      { id: 'id5503',
        name: '������ ���������� (20 ��.)',
        catalogNumber: '6.46.18.2.12�',
        images: [
          { imageURL: '6.46.18.2.12l.jpg' }
        ]
      },
      { id: 'id5504',
        name: '������ (5 ��.)',
        catalogNumber: '6.46.18.2.55',
        images: [
          { imageURL: '6.46.18.2.55.jpg' }
        ]
      },
      { id: 'id5505',
        name: '������� (20 ��.)',
        catalogNumber: '6.46.18.2.57',
        images: [
          { imageURL: '6.46.18.2.57.jpg' }
        ]
      },
      { id: 'id5506',
        name: '��������� (20 ��.)',
        catalogNumber: '6.46.18.2.59',
        images: [
          { imageURL: '6.46.18.2.59.jpg' }
        ]
      },
      { id: 'id5507',
        name: '����� ����������� (5 ��.)',
        catalogNumber: '6.46.18.2.61',
        images: [
          { imageURL: '6.46.18.2.61.jpg' }
        ]
      },
      { id: 'id5508',
        name: '�����-�������� (5 ��.)',
        catalogNumber: '6.46.18.2.63',
        images: [
          { imageURL: '6.46.18.2.63.jpg' }
        ]
      }
    ]
  },

  // 56
  { id: '56',
    name: '������� ��������',
    catalogNumber: '6.46.21',
    images: [
      { imageURL: '6.46.21.jpg' }
    ]
  },

  // 57
  { id: '57',
    name: '������������',
    catalogNumber: '2.46.23',
    images: [
      { imageURL: '2.46.23.jpg' }
    ]
  },

  // 58
  { id: '58',
    name: '����� ��������������',
    catalogNumber: '6.46.110'
  },

  // 59
  { id: '59',
    name: '������� �������� � ����� (2 ��.)',
    catalogNumber: '6.100.1',
    images: [
      { imageURL: '6.100.1.jpg',
        mapMarkers: [
          { top: '54.3',
            left: '76',
            width: '14',
            height: '3.5',
            href: '59,0'
          },
          { top: '54.5',
            left: '56.4',
            width: '16',
            height: '3.5',
            href: '59,1'
          },
          { top: '85.9',
            left: '62.6',
            width: '16',
            height: '3.5',
            href: '59,2'
          }
        ]
      }
    ],
    children: [
      { id: 'id5900',
        name: '�������� � ����� (2 ��.)',
        catalogNumber: '6.100.1.2',
        images: [
          { imageURL: '6.100.1.2.jpg' }
        ]
      },
      { id: 'id5901',
        name: '������ ������ (2 ��.)',
        catalogNumber: '6.100.1.38',
        images: [
          { imageURL: '6.100.1.38.jpg' }
        ]
      },
      { id: 'id5902',
        name: '���������� ����������� (2 ��.)',
        catalogNumber: '6.100.1.40',
        images: [
          { imageURL: '6.100.1.40.jpg' }
        ]
      }
    ]
  },

  // 60
  { id: '60',
    name: '������� ������� ������',
    catalogNumber: '6.100.3.�',
    images: [
      { imageURL: '6.100.3.d.jpg',
        mapMarkers: [
          { top: '89.4',
            left: '49.8',
            width: '12',
            height: '3.5',
            href: '60,0'
          },
          { top: '89.8',
            left: '31.4',
            width: '14.5',
            height: '3.5',
            href: '60,1'
          },
          { top: '89.4',
            left: '69.3',
            width: '14.5',
            height: '3.5',
            href: '60,2'
          },
          { top: '93.6',
            left: '12.3',
            width: '14.5',
            height: '3.5',
            href: '60,3'
          },
          { top: '89.7',
            left: '12.3',
            width: '14.5',
            height: '3.5',
            href: '60,4'
          },
          { top: '88.4',
            left: '89.9',
            width: '14.5',
            height: '3.5',
            href: '60,5'
          },
          { top: '93.7',
            left: '69.7',
            width: '14.5',
            height: '3.5',
            href: '60,6'
          }
        ]
      }
    ],
    children: [
      { id: 'id6000',
        name: '����� �������� ��������',
        catalogNumber: '6.100.3.5',
        images: [
          { imageURL: '6.100.3.5.jpg' }
        ]
      },
      { id: 'id6001',
        name: '���������',
        catalogNumber: '6.100.3.5.2',
        images: [
          { imageURL: '6.100.3.5.2.jpg' }
        ]
      },
      { id: 'id6002',
        name: '���������',
        catalogNumber: '6.100.3.5.3',
        images: [
          { imageURL: '6.100.3.5.3.jpg' }
        ]
      },
      { id: 'id6003',
        name: '������',
        catalogNumber: '6.100.3.5.16'
      },
      { id: 'id6004',
        name: '����������������',
        catalogNumber: '6.100.3.5.17',
        images: [
          { imageURL: '6.100.3.5.17.jpg' }
        ]
      },
      { id: 'id6005',
        name: '����� �������������',
        catalogNumber: '6.100.3.5.18',
        images: [
          { imageURL: '6.100.3.5.18.jpg' }
        ]
      },
      { id: 'id6006',
        name: '������� ������� (3 ��.)',
        catalogNumber: '6.100.3.5.19',
        images: [
          { imageURL: '6.100.3.5.19.jpg' }
        ]
      },
      { id: 'id6007',
        name: '���� �������',
        catalogNumber: '6.100.3.7.8.�',
        images: [
          { imageURL: '6.100.3.7.8.d.jpg' }
        ]
      }
    ]
  },

  // 61
  { id: '61',
    name: '����������� � ����������',
    catalogNumber: '6.100.31.�',
    images: [
      { imageURL: '6.100.31.a.jpg',
        mapMarkers: [
          { top: '15.6',
            left: '34.8',
            width: '10',
            height: '4',
            href: '61,0'
          },
          { top: '9.2',
            left: '35.2',
            width: '11',
            height: '4',
            href: '61,1'
          },
          { top: '33.4',
            left: '93.6',
            width: '10',
            height: '4',
            href: '61,2'
          },
          { top: '95',
            left: '75',
            width: '10',
            height: '4',
            href: '61,3'
          },
          { top: '95.5',
            left: '93.3',
            width: '10',
            height: '4',
            href: '61,4'
          },
          { top: '27.9',
            left: '93.7',
            width: '10',
            height: '4',
            href: '61,5'
          },
          { top: '39',
            left: '93.9',
            width: '10',
            height: '4',
            href: '61,6'
          },
          { top: '94.7',
            left: '55.8',
            width: '10',
            height: '4',
            href: '61,7'
          },
          { top: '40.8',
            left: '78.1',
            width: '10',
            height: '4',
            href: '61,7'
          },
          { top: '92.1',
            left: '83.2',
            width: '10',
            height: '4',
            href: '61,8'
          },
          { top: '36.2',
            left: '63.7',
            width: '10',
            height: '4',
            href: '61,8'
          },
          { top: '92.1',
            left: '93.5',
            width: '10',
            height: '4',
            href: '61,9'
          },
          { top: '91.7',
            left: '73.5',
            width: '10',
            height: '4',
            href: '61,9'
          },
          { top: '94.7',
            left: '45.6',
            width: '10',
            height: '4',
            href: '61,9'
          },
          { top: '49.5',
            left: '78.1',
            width: '10',
            height: '4',
            href: '61,10'
          },
          { top: '77',
            left: '54.2',
            width: '11',
            height: '4',
            href: '61,11'
          },
          { top: '94.6',
            left: '33.8',
            width: '11',
            height: '4',
            href: '61,12'
          },
          { top: '99',
            left: '56.2',
            width: '11',
            height: '4',
            href: '61,13'
          },
          { top: '62.4',
            left: '84.3',
            width: '11',
            height: '4',
            href: '61,14'
          },
          { top: '95.6',
            left: '12.8',
            width: '11',
            height: '4',
            href: '61,15'
          },
          { top: '59.5',
            left: '31.7',
            width: '10',
            height: '4',
            href: '61,16'
          }
        ]
      }
    ],
    children: [
      { id: 'id6100',
        name: '��� ��������������',
        catalogNumber: '6.100.31.2',
        images: [
          { imageURL: '6.100.31.2.jpg' }
        ]
      },
      { id: 'id6101',
        name: '�������� � �����',
        catalogNumber: '6.100.31.2.2',
        images: [
          { imageURL: '6.100.31.2.2.jpg' }
        ]
      },
      { id: 'id6102',
        name: '����������� ���������',
        catalogNumber: '6.100.30.�',
        images: [
          { imageURL: '6.100.30.a.jpg' }
        ]
      },
      { id: 'id6103',
        name: '�����',
        catalogNumber: '6.100.30.4.',
        images: [
          { imageURL: '6.100.30.4.jpg' }
        ]
      },
      { id: 'id6104',
        name: '����� ������������',
        catalogNumber: '6.100.30.1',
        images: [
          { imageURL: '6.100.30.1.jpg' }
        ]
      },
      { id: 'id6105',
        name: '������ ��������',
        catalogNumber: '6.100.30.1.2',
        images: [
          { imageURL: '6.100.30.1.2.jpg' }
        ]
      },
      { id: 'id6106',
        name: '�������',
        catalogNumber: '6.100.30.83',
        images: [
          { imageURL: '6.100.30.83.jpg' }
        ]
      },
      { id: 'id6107',
        name: '���� ������� (3 ��.)',
        catalogNumber: '6.100.30.89',
        images: [
          { imageURL: '6.100.30.89.jpg' }
        ]
      },
      { id: 'id6108',
        name: '���� ������� (2 ��.)',
        catalogNumber: '6.100.30.91',
        images: [
          { imageURL: '6.100.30.91.jpg' }
        ]
      },
      { id: 'id6109',
        name: '���� ������� (5 ��.)',
        catalogNumber: '6.100.30.92',
        images: [
          { imageURL: '6.100.30.92.jpg' }
        ]
      },
      { id: 'id6110',
        name: '����� ������������',
        catalogNumber: '6.100.30.94',
        images: [
          { imageURL: '6.100.30.94.jpg' }
        ]
      },
      { id: 'id6111',
        name: '������-���� (2 ��.)',
        catalogNumber: '6.100.30.100',
        images: [
          { imageURL: '6.100.30.100.jpg' }
        ]
      },
      { id: 'id6112',
        name: '���������',
        catalogNumber: '6.100.30.102',
        images: [
          { imageURL: '6.100.30.102.jpg' }
        ]
      },
      { id: 'id6113',
        name: '������',
        catalogNumber: '6.100.30.104',
        images: [
          { imageURL: '6.100.30.104.jpg' }
        ]
      },
      { id: 'id6114',
        name: '���� 3-� ���. (4 ��.)',
        catalogNumber: '6.100.30.106',
        images: [
          { imageURL: '6.100.30.106.jpg' }
        ]
      },
      { id: 'id6115',
        name: '��������',
        catalogNumber: '6.100.30.110',
        images: [
          { imageURL: '6.100.30.110.jpg' }
        ]
      },
      { id: 'id6116',
        name: '��������������� �������� (3 ��.)',
        catalogNumber: '6.100.30.111',
        images: [
          { imageURL: '6.100.30.111.jpg' }
        ]
      }
    ]
  },

  // 62
  { id: '62',
    name: '����� ��������',
    catalogNumber: '6.100.34.�',
    images: [
      { imageURL: '6.100.34.m.jpg',
        mapMarkers: [
          { top: '92.8',
            left: '50.7',
            width: '11',
            height: '3.5',
            href: '62,0'
          },
          { top: '97.8',
            left: '17.4',
            width: '11',
            height: '3.5',
            href: '62,1'
          },
          { top: '94.6',
            left: '17.5',
            width: '11',
            height: '3.5',
            href: '62,2'
          },
          { top: '42.8',
            left: '56.7',
            width: '11',
            height: '3.5',
            href: '62,3'
          },
          { top: '38.2',
            left: '56.7',
            width: '11',
            height: '3.5',
            href: '62,4'
          },
          { top: '86.9',
            left: '7.2',
            width: '11',
            height: '3.5',
            href: '62,5'
          },
          { top: '33.2',
            left: '56.5',
            width: '11',
            height: '3.5',
            href: '62,6'
          }
        ]
      }
    ],
    children: [
      { id: 'id6200',
        name: '����� ��������',
        catalogNumber: '6.100.34.1.�',
        images: [
          { imageURL: '6.100.34.1.a.jpg' }
        ]
      },
      { id: 'id6201',
        name: '���������',
        catalogNumber: '6.100.34.1.15',
        images: [
          { imageURL: '6.100.34.1.15.jpg' }
        ]
      },
      { id: 'id6202',
        name: '���������',
        catalogNumber: '6.100.34.1.16',
        images: [
          { imageURL: '6.100.34.1.16.jpg' }
        ]
      },
      { id: 'id6203',
        name: '�����-��������',
        catalogNumber: '6.100.34.1.41',
        images: [
          { imageURL: '6.100.34.1.41.jpg' }
        ]
      },
      { id: 'id6204',
        name: '������',
        catalogNumber: '6.100.34.1.38'
      },
      { id: 'id6205',
        name: '�����',
        catalogNumber: '6.100.34.1.43',
        images: [
          { imageURL: '6.100.34.1.43.jpg' }
        ]
      },
      { id: 'id6206',
        name: '������� ������� (6 ��.)',
        catalogNumber: '6.100.34.1.45',
        images: [
          { imageURL: '6.100.34.1.45.jpg' }
        ]
      }
    ]
  },

  // 63
  { id: '63',
    name: '����������',
    catalogNumber: '4.13.9.�',
    images: [
      { imageURL: '4.13.9.m.jpg' }
    ],
    children: [
      { id: 'id6300',
        name: '����������������',
        catalogNumber: '4.13.9.20',
        images: [
          { imageURL: '4.13.9.20.jpg' }
        ]
      }
    ]
  },

  // 64
  { id: '64',
    name: '�������� ��������',
    catalogNumber: '4.13.10.�',
    images: [
      { imageURL: '4.13.10.m.jpg',
        mapMarkers: [
          { top: '82.4',
            left: '80.4',
            width: '15',
            height: '4',
            href: '64,0'
          },
          { top: '64',
            left: '89.8',
            width: '15',
            height: '4',
            href: '64,1'
          },
          { top: '49',
            left: '12.3',
            width: '15',
            height: '4',
            href: '64,2'
          },
          { top: '16.6',
            left: '85.3',
            width: '15',
            height: '4',
            href: '64,3'
          }
        ]
      }
    ],
    children: [
      { id: 'id6400',
        name: '��������� (2 ��.)',
        catalogNumber: '4.13.10.27',
        images: [
          { imageURL: '4.13.10.27.jpg' }
        ]
      },
      { id: 'id6401',
        name: '������',
        catalogNumber: '4.13.10.30'
      },
      { id: 'id6402',
        name: '������ (2 ��.)',
        catalogNumber: '4.13.10.32',
        images: [
          { imageURL: '4.13.10.32.jpg' }
        ]
      },
      { id: 'id6403',
        name: '�����-��������',
        catalogNumber: '4.13.10.33'
      }
    ]
  },

  // 65
  { id: '65',
    name: '��������',
    catalogNumber: '4.13.59',
    images: [
      { imageURL: '4.13.59.jpg' }
    ]
  },

  // 66
  { id: '66',
    name: '����������� ����������� �������',
    catalogNumber: '6.70.�',
    images: [
      { imageURL: '6.70.n.jpg',
        mapMarkers: [
          { top: '74.2',
            left: '42.5',
            width: '18',
            height: '3.5',
            href: '66,0'
          },
          { top: '80.4',
            left: '43.3',
            width: '18',
            height: '3.5',
            href: '66,1'
          },
          { top: '74.4',
            left: '71.8',
            width: '18',
            height: '3.5',
            href: '66,2'
          }
        ]
      }
    ],
    children: [
      { id: 'id6600',
        name: '����� (24 ��.)',
        catalogNumber: '6.70.20.�'
      },
      { id: 'id6601',
        name: '����� (4 ��.)',
        catalogNumber: '6.70.21.�'
      },
      { id: 'id6602',
        name: '����� (30 ��.)',
        catalogNumber: '6.70.24.�'
      }
    ]
  },

  // 67
  { id: '67',
    name: '����� �������',
    catalogNumber: '6.247',
    images: [
      { imageURL: '6.247.jpg' }
    ]
  },

  // 68
  { id: '68',
    name: '��������',
    catalogNumber: '4.3.2.32',
    images: [
      { imageURL: '4.3.2.32.jpg' }
    ]
  },

  // 69
  { id: '69',
    name: '�������� �������',
    catalogNumber: '4.13�',
    images: [
      { imageURL: '4.13m.jpg',
        mapMarkers: [
          { top: '37.5',
            left: '87.5',
            width: '14',
            height: '3',
            href: '65'
          },
          { top: '90.5',
            left: '10',
            width: '15',
            height: '3',
            href: '63'
          },
          { top: '95',
            left: '10',
            width: '15',
            height: '3',
            href: '63,0'
          }
        ]
      }
    ]
  }
//======================
] // end Megauzels array
//======================

/*// 00.
  { id: '00',
    name: 'Template',
    catalogNumber: '',
    children: [
      { id: 'id0001',
        name: '',
        catalogNumber: '',
        children: [
          { id: 'id000101',
            name: '',
            catalogNumber: ''
  }]}]},  */
